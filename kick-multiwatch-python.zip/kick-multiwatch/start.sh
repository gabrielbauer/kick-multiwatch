#!/bin/sh
cd "$(dirname "$0")" || exit 1
if [ -n "$VIRTUAL_ENV" ] && [ -x "$VIRTUAL_ENV/bin/python" ]; then PY="$VIRTUAL_ENV/bin/python"; else
  SYS=$(command -v python3 || command -v python) || { echo 'Instale o Python em https://www.python.org/downloads/'; exit 1; }
  [ -x .venv/bin/python ] || "$SYS" -m venv .venv || { echo 'Nao consegui criar .venv. No Debian/Ubuntu rode: sudo apt install python3-venv'; exit 1; }
  PY=.venv/bin/python
fi
echo "Verificando pacotes..."
"$PY" -m pip install --quiet --disable-pip-version-check websockets curl_cffi || exit 1
exec "$PY" kickwatch.py -f channels.txt
