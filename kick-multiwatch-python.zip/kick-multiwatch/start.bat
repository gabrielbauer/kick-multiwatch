@echo off
title Kick Multiwatch
cd /d "%~dp0"
set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY (
  echo Python nao encontrado. Instale em https://www.python.org/downloads/
  echo e marque "Add Python to PATH" na instalacao. Depois rode de novo.
  pause
  exit /b 1
)
echo Verificando pacotes...
%PY% -m pip install --quiet --disable-pip-version-check websockets curl_cffi
%PY% kickwatch.py -f channels.txt
pause
