#!/usr/bin/env python3
"""kickwatch: follow many Kick channels at once with no video.

Chat for every channel arrives over ONE shared Pusher websocket (anonymous,
read-only). If KICK_SESSION_TOKEN is set, each live channel also gets a small
viewer websocket that sends the same watch-tracking events the kick.com player
sends, which is what credits watch time (channel points, drops).

A local dashboard (http://127.0.0.1:8787) shows your points per channel, lets
you add, remove and pause channels, and shows chat. It only listens on this
computer.

Kick's internal endpoints used here are undocumented and can change without
notice. Automated watch-time may break Kick's Terms of Service; use it on your
own account at your own risk.

  pip install websockets curl_cffi
  python kickwatch.py -f channels.txt
  KICK_SESSION_TOKEN=... python kickwatch.py -f channels.txt
"""
import argparse
import asyncio
import collections
import itertools
import json
import os
import random
import re
import sys
import time
import urllib.parse
import webbrowser

import websockets
from curl_cffi.requests import AsyncSession

# Kick rotates its Pusher app key; ask for the current one on each connect.
REALTIME_URL = "https://web.kick.com/api/v1/realtime/connection"
PUSHER_KEY, PUSHER_CLUSTER = "34bf7a0ff419a2a775b9", "us2"   # fallback
PUSHER_URL = "wss://ws-{}.pusher.com/app/{}?protocol=7&client=js&version=8.4.0&flash=false"
VIEWER_TOKEN_URL = "https://websockets.kick.com/viewer/v1/token"
VIEWER_WS_URL = "wss://websockets.kick.com/viewer/v1/connect?token={}"
CHANNEL_URL = "https://kick.com/api/v2/channels/{}"
POINTS_URL = "https://kick.com/api/v2/channels/{}/points"
ME_URL = "https://kick.com/api/v2/channels/{}/me"
USER_URL = "https://kick.com/api/v1/user"
# Public client token the kick.com web app sends with authenticated calls.
CLIENT_TOKEN = "e1393935a959b4020a4491574f6490129f678acdaa92760471263db43487f823"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")

REFRESH_EVERY = 120   # seconds between channel-state polls
POINTS_EVERY = 120    # seconds between points-balance polls
# Same cadence as the kick.com player: a watch event every ~10 s, and a
# handshake + ping every ~30 s. Fewer watch events credit less (or nothing).
WATCH_EVERY = (9.5, 12.5)
AUTO = -1             # rotate_every value: hand the slot on after each credit
TURN_GRACE = 7 * 60   # auto mode: give up on a slot with no credit after this
FAST_POINTS = 30      # seconds between balance checks on earning channels
HANDSHAKE_EVERY = (25, 35)
TOKEN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "token.txt")
SESSIONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sessoes")
# Reward prices used to recognise a redemption from a drop in the balance.
DEFAULT_PRICES = [
    {"name": "Bônus +15% XP PokeIdle", "cost": 300},
    {"name": "Bônus de +15% Capture Boost", "cost": 500},
    {"name": "Bônus de +15% Secret Lure", "cost": 1000},
]
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")
CHAT_BACKLOG = 60     # messages kept per channel for the dashboard

COLORS = [31, 32, 33, 34, 35, 36, 91, 92, 93, 94, 95, 96]
USE_COLOR = sys.stdout.isatty() and os.name != "nt" or os.environ.get("FORCE_COLOR")
SLUG_RE = re.compile(r"[a-z0-9_-]{1,40}")


def paint(text, n):
    return f"\x1b[{COLORS[n % len(COLORS)]}m{text}\x1b[0m" if USE_COLOR else text


def log(msg):
    print(f"{time.strftime('%H:%M:%S')} {msg}", flush=True)


def clean_slug(s):
    s = s.strip().lower().rstrip("/").rsplit("/", 1)[-1]
    return s if SLUG_RE.fullmatch(s) else None


def ws_connect(url, headers):
    # websockets >= 14 renamed extra_headers to additional_headers.
    try:
        return websockets.connect(url, additional_headers=headers, ping_interval=None,
                                  open_timeout=20, close_timeout=5, max_size=2**20)
    except TypeError:
        return websockets.connect(url, extra_headers=headers, ping_interval=None,
                                  open_timeout=20, close_timeout=5, max_size=2**20)


def find_key(o, *keys):
    """First value under any of `keys`, searching nested dicts/lists."""
    if isinstance(o, dict):
        for k in keys:
            if k in o and not isinstance(o[k], (dict, list)):
                return o[k]
        o = list(o.values())
    if isinstance(o, list):
        for v in o:
            r = find_key(v, *keys)
            if r is not None:
                return r
    return None


def match_spend(drop, prices):
    """Explain a balance drop with the fewest rewards (up to 3) whose prices add
    up to it. A +10/+20 watch credit can land in the same check, so those
    offsets are tried too. Returns (names, credit_offset) or (None, 0)."""
    costs = [(p["name"], p["cost"]) for p in prices if p.get("cost")]
    for extra in (0, 10, 20):
        target = drop + extra
        for n in (1, 2, 3):
            for combo in itertools.combinations_with_replacement(costs, n):
                if sum(c for _, c in combo) == target:
                    return [name for name, _ in combo], extra
    return None, 0


class Channel:
    def __init__(self, slug, idx):
        self.slug, self.idx = slug, idx
        self.channel_id = self.chatroom_id = self.livestream_id = self.user_id = None
        self.events_sent, self.last_event = 0, None
        self.watching_since = None
        self.in_turn = False                # holding an earning slot (auto mode)
        self.turn_started = None
        self.last_turn = 0.0                # when its last turn ended (0 = never had one)
        self.last_credit = None             # when Kick last added points here
        self.title, self.viewers, self.category = "", 0, ""
        self.enabled = True                 # earn points on this channel
        self.watch_task = None
        self.watch_state = "idle"           # idle | connecting | watching | error
        self.watch_error = ""
        self.credited_secs = 0.0
        self.points = self.points_start = None
        self.earned = self.spent = 0        # this session, from balance changes
        self.points_at = None
        self.chat = collections.deque(maxlen=CHAT_BACKLOG)

    @property
    def live(self):
        return self.livestream_id is not None

    def tag(self):
        return paint(f"[{self.slug}]", self.idx)

    def public(self):
        gained = self.earned if self.points_start is not None else None
        return {"slug": self.slug, "idx": self.idx, "live": self.live, "title": self.title,
                "viewers": self.viewers, "category": self.category, "enabled": self.enabled,
                "watch": self.watch_state, "watch_error": self.watch_error,
                "credited_min": round(self.credited_secs / 60), "points": self.points,
                "gained": gained, "earned": self.earned, "spent": self.spent,
                "points_at": self.points_at,
                "events_sent": self.events_sent, "last_event": self.last_event,
                "last_credit": self.last_credit, "in_turn": self.in_turn,
                "turn_started": self.turn_started,
                # Kick should credit 10 points per 5 min; flag channels that
                # have been watched for 12+ min with nothing to show for it.
                "subscribed": False,
                "no_points": bool(self.watch_state == "watching" and self.watching_since
                                  and time.time() - self.watching_since > 720
                                  and self.points is not None and self.points_at
                                  and self.points_at > self.watching_since + 660
                                  and not gained)}


class Kick:
    def __init__(self, token):
        self.token = token
        self.http = AsyncSession(impersonate="chrome", timeout=20)

    def headers(self, auth=False, referer="https://kick.com/"):
        h = {"Accept": "application/json", "Origin": "https://kick.com",
             "Referer": referer, "User-Agent": UA}
        if auth and self.token:
            h["Authorization"] = f"Bearer {self.token}"
            h["X-Client-Token"] = CLIENT_TOKEN
        return h

    async def get_json(self, url, auth=False, referer="https://kick.com/", extra=None):
        r = await self.http.get(url, headers={**self.headers(auth, referer), **(extra or {})})
        if r.status_code == 403:
            raise RuntimeError("bloqueado pelo Cloudflare (403), tentando de novo")
        if r.status_code == 404:
            raise LookupError("não encontrado")
        if r.status_code == 401:
            raise PermissionError("a Kick recusou o token de sessão (401); copie um novo")
        r.raise_for_status()
        return r.json()

    async def pusher_url(self):
        key, cluster = PUSHER_KEY, PUSHER_CLUSTER
        try:
            r = await self.http.post(REALTIME_URL, headers=self.headers(),
                                     json={"accepted_providers": ["pusher"]})
            data = r.json()
            k, c = find_key(data, "app_key"), find_key(data, "cluster")
            if isinstance(k, str) and k.isalnum():
                key = k
            if isinstance(c, str) and re.fullmatch(r"[a-z0-9-]{1,20}", c):
                cluster = c
        except Exception as e:
            log(f"falha ao buscar a chave do chat ({e}); usando a chave embutida")
        return PUSHER_URL.format(cluster, key)

    async def viewer_token(self, ch=None):
        # kick.com scopes the viewer token to the channel being watched.
        extra = {}
        if ch is not None and ch.channel_id:
            extra = {"X-Chatroom": str(ch.channel_id), "X-User-Id": str(ch.user_id or ch.channel_id)}
        data = await self.get_json(VIEWER_TOKEN_URL, auth=True,
                                   referer=f"https://kick.com/{ch.slug}" if ch else "https://kick.com/",
                                   extra=extra)
        token = find_key(data, "token", "websocket_token")
        if not token:
            raise PermissionError("a Kick não devolveu o token de espectador; conecte a conta de novo")
        return token

    async def points(self, slug):
        data = await self.get_json(POINTS_URL.format(slug), auth=True,
                                   referer=f"https://kick.com/{slug}")
        p = find_key(data, "points", "balance")
        return int(p) if isinstance(p, (int, float, str)) and str(p).lstrip("-").isdigit() else None

    async def username(self):
        """Logged-in username; raises PermissionError if Kick rejects the token."""
        try:
            data = await self.get_json(USER_URL, auth=True)
        except PermissionError:
            raise
        except Exception:
            return None
        return find_key(data, "username")


async def refresh(kick, ch):
    """Poll one channel's state; returns True if live status changed."""
    data = await kick.get_json(CHANNEL_URL.format(ch.slug))
    ch.channel_id = data.get("id")
    ch.chatroom_id = (data.get("chatroom") or {}).get("id")
    ch.user_id = data.get("user_id") or (data.get("user") or {}).get("id")
    ls = data.get("livestream") or None
    was_live, old_ls = ch.live, ch.livestream_id
    if ls and ls.get("is_live", True):
        ch.livestream_id = ls.get("id")
        ch.title = (ls.get("session_title") or "").strip()
        ch.viewers = ls.get("viewer_count") or 0
        cats = ls.get("categories") or []
        ch.category = (cats[0] or {}).get("name", "") if cats else ""
    else:
        ch.livestream_id = None
        ch.viewers = 0
    return was_live != ch.live or old_ls != ch.livestream_id


class App:
    def __init__(self, kick, path, print_chat):
        self.kick, self.path, self.print_chat = kick, path, print_chat
        self.points = False           # True once the account is connected
        # Kick credits about 2 channels per 5 minutes per account, however many
        # are watched, so earning focuses on N channels and can rotate.
        self.max_earning = 2          # 0 = send the watch signal on every live channel
        self.rotate_every = AUTO      # AUTO = after each credit; minutes; 0 = top N by priority
        self.rot_offset = 0
        self.subs = set()             # channels you're subscribed to (2x points)
        self.prices = [dict(p) for p in DEFAULT_PRICES]
        self.spend_log = []           # redemptions inferred this session
        self.session_file = None
        self.next_rotation = None
        try:
            with open(SETTINGS_FILE) as f:
                saved = json.load(f)
            self.max_earning = max(0, int(saved.get("max_earning", 2)))
            self.rotate_every = max(AUTO, int(saved.get("rotate_every", AUTO)))
            self.subs = set(map(str, saved.get("subscribed") or []))
            self.prices = self.clean_prices(saved.get("prices")) or self.prices
        except (OSError, ValueError, TypeError):
            pass
        self.account = {"state": "disconnected", "error": "", "saved": False}
        self.channels = {}            # slug -> Channel, in insertion order
        self.next_idx = 0
        self.chat_ws = None
        self.chat_state = "connecting"
        self.user = None
        self.started = time.time()
        self.clients = set()          # dashboard event queues

    # ---- dashboard events -------------------------------------------------
    def emit(self, event, data):
        line = f"event: {event}\ndata: {json.dumps(data)}\n\n".encode()
        for q in list(self.clients):
            try:
                q.put_nowait(line)
            except asyncio.QueueFull:
                pass

    def state(self):
        chans = [dict(c.public(), subscribed=c.slug in self.subs) for c in self.channels.values()]
        return {"user": self.user, "points_mode": self.points, "account": self.account,
                "max_earning": self.max_earning, "rotate_every": self.rotate_every,
                "next_rotation": self.next_rotation,
                "chat": self.chat_state, "started": self.started, "channels": chans,
                "prices": self.prices, "spend_log": self.spend_log[-200:],
                "session_file": os.path.basename(self.session_file) if self.session_file else None,
                "earned": sum(c.earned for c in self.channels.values()),
                "spent": sum(c.spent for c in self.channels.values())}

    def push_state(self):
        self.emit("state", self.state())

    # ---- account connection -----------------------------------------------
    async def connect(self, raw, remember=False):
        """Check a session token with Kick; start earning only if it works."""
        token = urllib.parse.unquote(raw or "").strip()
        token = re.sub(r"^(bearer\s+|session_token=)", "", token, flags=re.I).strip().strip('"')
        if not token or len(token) > 2000 or any(c.isspace() for c in token):
            self.account = {"state": "failed", "error": "Isso não parece um token de sessão.", "saved": False}
            self.push_state()
            return False
        self.stop_watching()
        old = self.kick.token
        self.kick.token = token
        self.account = {"state": "checking", "error": "", "saved": False}
        self.push_state()
        try:
            user = await self.kick.username()
            probe = next((c for c in self.channels.values() if c.channel_id), None)
            await self.kick.viewer_token(probe)
        except PermissionError:
            err = "A Kick recusou este token. Entre de novo em kick.com e copie um session_token novo."
        except Exception as e:
            err = f"Não consegui falar com a Kick para validar o token ({e}). Tente de novo em um minuto."
        else:
            err = None
        if err:
            self.kick.token = old if old != token else None
            self.account = {"state": "failed", "error": err, "saved": False}
            log(f"conta: {err}")
            self.push_state()
            return False
        self.user, self.points = user, True
        saved = False
        if remember:
            try:
                fd = os.open(TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, "w") as f:
                    f.write(token + "\n")
                saved = True
            except OSError as e:
                log(f"não consegui salvar token.txt: {e}")
        self.account = {"state": "connected", "error": "", "saved": saved or os.path.exists(TOKEN_FILE)}
        log(f"conta conectada{' como ' + user if user else ''}; ganhando pontos")
        for ch in self.channels.values():
            ch.points = ch.points_start = None
            asyncio.create_task(self.update_points(ch))
            asyncio.create_task(self.detect_sub(ch))
            self.ensure_watch(ch)
        self.push_state()
        return True

    def stop_watching(self):
        self.points = False
        for ch in self.channels.values():
            if ch.watch_task:
                ch.watch_task.cancel()
                ch.watch_task = None
            ch.watch_state, ch.watch_error = "idle", ""

    def disconnect(self, forget):
        self.stop_watching()
        self.kick.token, self.user = None, None
        if forget:
            try:
                os.remove(TOKEN_FILE)
            except OSError:
                pass
        self.account = {"state": "disconnected", "error": "", "saved": os.path.exists(TOKEN_FILE)}
        log("conta desconectada")
        self.push_state()

    # ---- session: earned / spent / redemptions ----------------------------
    @staticmethod
    def clean_prices(raw):
        out = []
        for p in raw or []:
            try:
                name, cost = str(p["name"]).strip()[:60], int(p["cost"])
            except (KeyError, TypeError, ValueError):
                continue
            if name and 0 < cost <= 10_000_000:
                out.append({"name": name, "cost": cost})
        return out[:20]

    def record_spend(self, ch, before, after):
        drop = before - after
        names, extra = match_spend(drop, self.prices)
        if extra:
            ch.earned += extra          # a watch credit landed in the same check
        spent = drop + extra
        ch.spent += spent
        entry = {"at": time.time(), "slug": ch.slug, "spent": spent, "before": before, "after": after,
                 "items": names or [], "known": names is not None}
        self.spend_log.append(entry)
        what = " + ".join(names) if names else "gasto sem prêmio correspondente"
        log(f"{ch.tag()} resgate: {what} (-{spent} pontos)")

    def save_session(self):
        try:
            os.makedirs(SESSIONS_DIR, exist_ok=True)
            if not self.session_file:
                stamp = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime(self.started))
                self.session_file = os.path.join(SESSIONS_DIR, f"sessao-{stamp}.json")
            data = {
                "inicio": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.started)),
                "conta": self.user,
                "ganhos": sum(c.earned for c in self.channels.values()),
                "gastos": sum(c.spent for c in self.channels.values()),
                "canais": {c.slug: {"saldo": c.points, "ganhos": c.earned, "gastos": c.spent}
                           for c in self.channels.values()},
                "resgates": [{**e, "at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(e["at"]))}
                             for e in self.spend_log],
            }
            with open(self.session_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except OSError as e:
            log(f"não consegui salvar a sessão: {e}")

    def reset(self):
        """Opções > remover token: forget the account and start a new session."""
        self.disconnect(forget=True)
        for ch in self.channels.values():
            ch.points = ch.points_start = ch.points_at = ch.last_credit = None
            ch.earned = ch.spent = 0
            ch.in_turn, ch.turn_started, ch.last_turn = False, None, 0.0
            ch.credited_secs, ch.events_sent, ch.last_event = 0.0, 0, None
        self.spend_log, self.session_file = [], None
        self.started = time.time()
        log("sessão reiniciada; informe um novo token no painel")
        self.push_state()

    # ---- channel management -----------------------------------------------
    def save(self):
        if not self.path:
            return
        try:
            with open(self.path, "w") as f:
                f.write("\n".join(self.channels) + "\n")
        except OSError as e:
            log(f"não consegui salvar {self.path}: {e}")

    async def add(self, slug, save=True):
        if slug in self.channels:
            return self.channels[slug]
        ch = Channel(slug, self.next_idx)
        for attempt in range(3):
            try:
                await refresh(self.kick, ch)
                break
            except LookupError:
                raise
            except Exception as e:
                log(f"{slug}: {e}")
                if attempt == 2:
                    raise
                await asyncio.sleep(3 * (attempt + 1))
        if not ch.chatroom_id:
            raise LookupError("canal sem chat")
        self.next_idx += 1
        self.channels[slug] = ch
        await self.subscribe(ch)
        if save:
            self.save()
        log(f"{ch.tag()} adicionado{' (AO VIVO)' if ch.live else ''}")
        asyncio.create_task(self.update_points(ch))
        if self.points:
            asyncio.create_task(self.detect_sub(ch))
        self.ensure_watch(ch)
        self.push_state()
        return ch

    async def remove(self, slug):
        ch = self.channels.pop(slug, None)
        if not ch:
            return
        if slug in self.subs:
            self.subs.discard(slug)
            self.save_settings()
        if ch.watch_task:
            ch.watch_task.cancel()
        await self.subscribe(ch, unsubscribe=True)
        self.save()
        log(f"{ch.tag()} removido")
        self.push_state()

    def set_enabled(self, slug, on):
        ch = self.channels.get(slug)
        if not ch:
            return
        ch.enabled = on
        self.rebalance()
        self.push_state()

    def earning(self):
        return [c for c in self.channels.values() if c.watch_task and not c.watch_task.done()]

    def eligible(self, ch):
        return self.points and ch.enabled and ch.live

    def wanted(self):
        """Channels that should send the watch signal now: the first N live
        ones in priority order, shifted by the rotation offset."""
        cands = [c for c in self.channels.values() if self.eligible(c)]
        if not self.max_earning:
            return cands
        # Subscribed channels earn double, so they always get a slot first;
        # rotation only moves the remaining slots.
        subs = [c for c in cands if c.slug in self.subs]
        rest = [c for c in cands if c.slug not in self.subs]
        if self.rotate_every == AUTO:
            # Channels mid-turn keep their slot until Kick credits them; free
            # slots go to whoever has waited longest since its last turn.
            slots = max(0, self.max_earning - len(subs))
            keep = [c for c in rest if c.in_turn][:slots]
            order = {c.slug: i for i, c in enumerate(self.channels.values())}
            waiting = sorted((c for c in rest if c not in keep),
                             key=lambda c: (c.last_turn, order[c.slug]))
            rest = keep + waiting
        elif self.rotate_every and rest:
            k = self.rot_offset % len(rest)
            rest = rest[k:] + rest[:k]
        return (subs + rest)[:self.max_earning]

    def end_turn(self, ch, why):
        if not ch.in_turn:
            return
        ch.in_turn, ch.last_turn = False, time.time()
        if self.rotate_every == AUTO and self.max_earning:
            self.rebalance()
            nxt = [c.slug for c in self.wanted() if c.in_turn and c is not ch]
            log(f"{ch.tag()} {why}; agora ganhando em {', '.join(nxt) or 'nenhum outro'}")
            self.push_state()

    def rebalance(self):
        want = set(map(id, self.wanted()))
        for ch in self.channels.values():
            running = ch.watch_task is not None and not ch.watch_task.done()
            if id(ch) in want:
                if not ch.in_turn:
                    ch.in_turn, ch.turn_started = True, time.time()
                if not running:
                    ch.watch_state = "connecting"
                    ch.watch_task = asyncio.create_task(self.watch_loop(ch))
            else:
                if ch.in_turn:
                    ch.in_turn, ch.last_turn = False, time.time()
                if running:
                    ch.watch_task.cancel()
                    ch.watch_task = None
                ch.watch_state = "queued" if self.eligible(ch) else "idle"

    # Older call sites; everything goes through rebalance now.
    def ensure_watch(self, ch=None):
        self.rebalance()

    fill_slots = ensure_watch

    def save_settings(self):
        try:
            with open(SETTINGS_FILE, "w") as f:
                json.dump({"max_earning": self.max_earning, "rotate_every": self.rotate_every,
                           "subscribed": sorted(self.subs), "prices": self.prices}, f)
        except OSError as e:
            log(f"não consegui salvar settings.json: {e}")

    def set_settings(self, max_earning=None, rotate_every=None, prices=None):
        if prices is not None:
            self.prices = self.clean_prices(prices)
        if max_earning is not None:
            self.max_earning = max(0, int(max_earning))
        if rotate_every is not None:
            self.rotate_every = max(AUTO, int(rotate_every))
            self.next_rotation = time.time() + self.rotate_every * 60 if self.rotate_every > 0 else None
        self.save_settings()
        self.rebalance()
        self.push_state()

    def set_sub(self, slug, on):
        if slug not in self.channels:
            return
        (self.subs.add if on else self.subs.discard)(slug)
        self.save_settings()
        self.rebalance()
        self.push_state()

    async def detect_sub(self, ch):
        """Best effort: ask Kick whether you're subscribed to this channel."""
        try:
            data = await self.kick.get_json(ME_URL.format(ch.slug), auth=True,
                                            referer=f"https://kick.com/{ch.slug}")
        except Exception:
            return
        sub = data.get("subscription") if isinstance(data, dict) else None
        if sub or (isinstance(data, dict) and data.get("is_subscribed") is True):
            if ch.slug not in self.subs:
                log(f"{ch.tag()} você é inscrito aqui: ganha primeiro (pontos em dobro)")
                self.subs.add(ch.slug)
                self.save_settings()
                self.rebalance()
                self.push_state()

    def move(self, slug, delta):
        """Change a channel's priority; earlier channels earn first."""
        order = list(self.channels)
        if slug not in order:
            return
        i = order.index(slug)
        j = max(0, min(len(order) - 1, i + delta))
        order.insert(j, order.pop(i))
        self.channels = {s: self.channels[s] for s in order}
        self.save()
        self.rebalance()
        self.push_state()

    async def rotate_loop(self):
        while True:
            await asyncio.sleep(15)
            if not (self.rotate_every and self.max_earning and self.points):
                continue
            if self.rotate_every == AUTO:
                for ch in list(self.channels.values()):
                    if (ch.in_turn and ch.slug not in self.subs and ch.turn_started
                            and time.time() - ch.turn_started > TURN_GRACE):
                        self.end_turn(ch, f"sem pontos após {TURN_GRACE // 60} min")
                continue
            if self.next_rotation is None:
                self.next_rotation = time.time() + self.rotate_every * 60
            if time.time() >= self.next_rotation:
                live_subs = sum(1 for c in self.channels.values() if self.eligible(c) and c.slug in self.subs)
                self.rot_offset += max(1, self.max_earning - live_subs)
                self.next_rotation = time.time() + self.rotate_every * 60
                self.rebalance()
                names = ", ".join(c.slug for c in self.wanted())
                log(f"rodízio: agora ganhando em {names or 'nenhum ao vivo'}")
                self.push_state()

    async def update_points(self, ch):
        if not self.points:
            return
        try:
            p = await self.kick.points(ch.slug)
        except Exception as e:
            log(f"{ch.tag()} falha ao ler os pontos: {e}")
            return
        if p is not None:
            if ch.points_start is None:
                ch.points_start = p
            before = ch.points
            credited = before is not None and p > before
            if before is not None and p != before:
                log(f"{ch.tag()} pontos {before} -> {p}")
            if credited:
                ch.earned += p - before
            elif before is not None and p < before:
                self.record_spend(ch, before, p)
            ch.points, ch.points_at = p, time.time()
            if before is not None and p != before:
                self.save_session()
            if credited:
                ch.last_credit = time.time()
                if ch.slug not in self.subs:
                    self.end_turn(ch, "recebeu os pontos")

    # ---- chat -------------------------------------------------------------
    async def subscribe(self, ch, unsubscribe=False):
        ws = self.chat_ws
        if ws is None:
            return
        ev = "pusher:unsubscribe" if unsubscribe else "pusher:subscribe"
        names = [f"chatrooms.{ch.chatroom_id}.v2"] + ([f"channel.{ch.channel_id}"] if ch.channel_id else [])
        try:
            for n in names:
                await ws.send(json.dumps({"event": ev, "data": {"auth": "", "channel": n}}))
        except Exception:
            pass  # the reconnect loop resubscribes everything

    def on_chat(self, msg):
        d = json.loads(msg.get("data") or "{}")
        room = d.get("chatroom_id")
        if room is None:
            parts = msg.get("channel", "").split(".")
            room = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else None
        ch = next((c for c in self.channels.values() if c.chatroom_id == room), None)
        if not ch:
            return
        sender = d.get("sender") or {}
        item = {"slug": ch.slug, "idx": ch.idx, "ts": time.time(),
                "user": sender.get("username", "?"),
                "color": (sender.get("identity") or {}).get("color") or "",
                "text": d.get("content", "")}
        ch.chat.append(item)
        self.emit("chat", item)
        if self.print_chat:
            print(f"{ch.tag()} {item['user']}: {item['text']}", flush=True)

    async def chat_loop(self):
        """One Pusher socket carries chat for every channel."""
        backoff = 5
        while True:
            try:
                url = await self.kick.pusher_url()
                async with ws_connect(url, {"Origin": "https://kick.com", "User-Agent": UA}) as ws:
                    self.chat_ws = ws
                    for ch in list(self.channels.values()):
                        await self.subscribe(ch)
                    self.chat_state = "connected"
                    log(f"chat conectado: {len(self.channels)} salas em uma conexão")
                    self.push_state()
                    backoff = 5
                    last_ping = time.monotonic()
                    while True:
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=30)
                        except asyncio.TimeoutError:
                            raw = None
                        if time.monotonic() - last_ping > 60:
                            await ws.send('{"event":"pusher:ping","data":{}}')
                            last_ping = time.monotonic()
                        if raw is None:
                            continue
                        msg = json.loads(raw)
                        ev = msg.get("event", "")
                        if ev == "pusher:ping":
                            await ws.send('{"event":"pusher:pong","data":{}}')
                        elif ev == "pusher:error":
                            raise RuntimeError((msg.get("data") or {}).get("message", "pusher error"))
                        elif ev == "App\\Events\\ChatMessageEvent":
                            self.on_chat(msg)
                        elif ev in ("App\\Events\\StreamerIsLive", "App\\Events\\StopStreamBroadcast"):
                            asyncio.create_task(self.refresh_all())
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.chat_ws, self.chat_state = None, "reconnecting"
                self.push_state()
                log(f"chat caiu ({e}); reconectando em {backoff}s")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 120)

    # ---- watching ---------------------------------------------------------
    async def watch_loop(self, ch):
        """Viewer socket for one live channel: handshake, ping, watch events."""
        backoff = 5
        try:
            while ch.live and ch.enabled and ch.slug in self.channels:
                ch.watch_state = "connecting"
                try:
                    token = await self.kick.viewer_token(ch)
                    async with ws_connect(VIEWER_WS_URL.format(token),
                                          {"Origin": "https://kick.com", "User-Agent": UA}) as ws:
                        log(f"{ch.tag()} assistindo")
                        ch.watch_state, ch.watch_error = "watching", ""
                        ch.watching_since = ch.watching_since or time.time()
                        self.push_state()
                        backoff = 5
                        next_hs = next_watch = 0.0
                        heard = 0
                        while ch.live and ch.enabled and self.points:
                            now = time.monotonic()
                            if now >= next_hs:
                                await ws.send(json.dumps({"type": "channel_handshake",
                                                          "data": {"message": {"channelId": int(ch.channel_id)}}}))
                                await ws.send('{"type":"ping"}')
                                next_hs = now + random.uniform(*HANDSHAKE_EVERY)
                            if now >= next_watch:
                                await ws.send(json.dumps({"type": "user_event", "data": {"message": {
                                    "name": "tracking.user.watch.livestream",
                                    "channel_id": int(ch.channel_id),
                                    "livestream_id": int(ch.livestream_id)}}}))
                                if ch.last_event:
                                    ch.credited_secs += min(time.time() - ch.last_event, 15)
                                ch.events_sent += 1
                                ch.last_event = time.time()
                                next_watch = now + random.uniform(*WATCH_EVERY)
                            try:
                                raw = await asyncio.wait_for(ws.recv(), timeout=max(0.5, min(next_hs, next_watch) - now))
                            except asyncio.TimeoutError:
                                continue
                            if raw == "ping" or ('"ping"' in raw and '"type"' in raw):
                                await ws.send('{"type":"pong"}')
                            elif heard < 3 and "pong" not in raw:
                                # Show what Kick says back; useful when points don't arrive.
                                heard += 1
                                log(f"{ch.tag()} resposta da kick: {str(raw)[:200]}")
                except asyncio.CancelledError:
                    raise
                except PermissionError as e:
                    ch.watch_state, ch.watch_error = "error", str(e)
                    self.push_state()
                    log(f"{ch.tag()} {e}")
                    await asyncio.sleep(60)
                except Exception as e:
                    ch.watch_state, ch.watch_error = "error", f"conexão caiu: {e}"
                    self.push_state()
                    log(f"{ch.tag()} conexão de espectador caiu ({e}); nova tentativa em {backoff}s")
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 120)
        finally:
            ch.watching_since = None
            if ch.watch_state != "queued" and (ch.watch_state != "error" or not ch.live):
                ch.watch_state = "idle"
            if ch.watch_task is asyncio.current_task():
                ch.watch_task = None
            self.fill_slots()           # hand the free slot to a queued channel
            self.push_state()

    # ---- background loops -------------------------------------------------
    async def refresh_all(self):
        for ch in list(self.channels.values()):
            try:
                if await refresh(self.kick, ch):
                    log(f"{ch.tag()} {'AO VIVO: ' + ch.title if ch.live else 'offline'}")
            except Exception as e:
                log(f"{ch.tag()} falha ao atualizar: {e}")
                continue
            self.ensure_watch(ch)
            await asyncio.sleep(0.5 + random.random())
        self.push_state()

    async def poll_loop(self):
        while True:
            await asyncio.sleep(REFRESH_EVERY)
            await self.refresh_all()

    async def points_loop(self):
        # Earning channels are checked often so a credit is noticed quickly
        # (auto rotation hands the slot on right after it); the rest slowly.
        while True:
            await asyncio.sleep(FAST_POINTS)
            if not self.points:
                continue
            now = time.time()
            for ch in list(self.channels.values()):
                due = FAST_POINTS if ch.in_turn else POINTS_EVERY
                if ch.points_at is None or now - ch.points_at >= due - 2:
                    await self.update_points(ch)
                    await asyncio.sleep(0.5 + random.random())
            self.push_state()

    async def tick_loop(self):
        while True:
            await asyncio.sleep(5)
            if self.clients:
                self.push_state()

    async def status_loop(self, every):
        while True:
            await asyncio.sleep(every)
            rows = []
            for ch in self.channels.values():
                state = "VIVO" if ch.live else "off "
                pts = f"  {ch.points} pontos" if ch.points is not None else ""
                rows.append(f"  {ch.tag()} {state} {ch.viewers:>6} espectadores  {ch.watch_state}{pts}")
            log("status\n" + "\n".join(rows))


# ---- local dashboard server --------------------------------------------------

async def serve_dashboard(app, port):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}

    async def respond(w, status, body=b"", ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        elif isinstance(body, str):
            body = body.encode()
        w.write(f"HTTP/1.1 {status}\r\nContent-Type: {ctype}\r\nContent-Length: {len(body)}\r\n"
                "Cache-Control: no-store\r\nConnection: close\r\n\r\n".encode() + body)
        await w.drain()

    async def handle(r, w):
        try:
            head = await asyncio.wait_for(r.readuntil(b"\r\n\r\n"), 10)
            lines = head.decode("latin-1").split("\r\n")
            method, target, _ = lines[0].split(" ", 2)
            hdrs = {k.strip().lower(): v.strip() for k, v in
                    (l.split(":", 1) for l in lines[1:] if ":" in l)}
            body = b""
            n = int(hdrs.get("content-length") or 0)
            if 0 < n < 10000:
                body = await r.readexactly(n)
            # Only this computer's browser, and no cross-site writes.
            if hdrs.get("host") not in allowed_hosts:
                return await respond(w, "403 Forbidden", {"error": "bad host"})
            if method != "GET" and hdrs.get("x-kickwatch") != "1":
                return await respond(w, "403 Forbidden", {"error": "missing header"})
            path = urllib.parse.urlsplit(target).path

            if method == "GET" and path == "/":
                return await respond(w, "200 OK", DASHBOARD_HTML, "text/html; charset=utf-8")
            if method == "GET" and path == "/api/state":
                return await respond(w, "200 OK", app.state())
            if method == "GET" and path == "/events":
                q = asyncio.Queue(maxsize=1000)
                app.clients.add(q)
                try:
                    w.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n"
                            b"Cache-Control: no-store\r\nConnection: keep-alive\r\n\r\n")
                    w.write(f"event: state\ndata: {json.dumps(app.state())}\n\n".encode())
                    backlog = sorted((m for c in app.channels.values() for m in c.chat),
                                     key=lambda m: m["ts"])[-300:]
                    w.write(f"event: backlog\ndata: {json.dumps(backlog)}\n\n".encode())
                    await w.drain()
                    while True:
                        try:
                            line = await asyncio.wait_for(q.get(), 15)
                        except asyncio.TimeoutError:
                            line = b": keepalive\n\n"
                        w.write(line)
                        await w.drain()
                finally:
                    app.clients.discard(q)
            if method == "POST" and path == "/api/connect":
                req = json.loads(body or b"{}")
                await app.connect(req.get("token", ""), bool(req.get("remember")))
                return await respond(w, "200 OK", app.state())
            if method == "POST" and path == "/api/settings":
                req = json.loads(body or b"{}")
                try:
                    app.set_settings(req.get("max_earning"), req.get("rotate_every"), req.get("prices"))
                except (TypeError, ValueError):
                    return await respond(w, "400 Bad Request", {"error": "as opções precisam ser números"})
                return await respond(w, "200 OK", app.state())
            if method == "POST" and path == "/api/reset":
                app.reset()
                return await respond(w, "200 OK", app.state())
            if method == "POST" and path == "/api/disconnect":
                app.disconnect(bool(json.loads(body or b"{}").get("forget")))
                return await respond(w, "200 OK", app.state())
            if method == "POST" and path == "/api/channels":
                slug = clean_slug((json.loads(body or b"{}").get("slug") or ""))
                if not slug:
                    return await respond(w, "400 Bad Request", {"error": "Esse não é um nome de canal válido."})
                try:
                    await app.add(slug)
                except LookupError:
                    return await respond(w, "404 Not Found", {"error": f"A Kick não tem nenhum canal chamado {slug}."})
                except Exception as e:
                    return await respond(w, "502 Bad Gateway", {"error": f"A Kick não respondeu: {e}"})
                return await respond(w, "200 OK", app.state())
            sb = re.fullmatch(r"/api/channels/([a-z0-9_-]+)/sub", path)
            if sb and method == "POST":
                app.set_sub(sb.group(1), bool(json.loads(body or b"{}").get("on")))
                return await respond(w, "200 OK", app.state())
            mv = re.fullmatch(r"/api/channels/([a-z0-9_-]+)/(up|down)", path)
            if mv and method == "POST":
                app.move(mv.group(1), -1 if mv.group(2) == "up" else 1)
                return await respond(w, "200 OK", app.state())
            m = re.fullmatch(r"/api/channels/([a-z0-9_-]+)(/watch)?", path)
            if m and method == "DELETE" and not m.group(2):
                await app.remove(m.group(1))
                return await respond(w, "200 OK", app.state())
            if m and method == "POST" and m.group(2):
                app.set_enabled(m.group(1), bool(json.loads(body or b"{}").get("on")))
                return await respond(w, "200 OK", app.state())
            if m and method == "POST" and not m.group(2):
                ch = app.channels.get(m.group(1))
                if ch:
                    await app.update_points(ch)
                    app.push_state()
                return await respond(w, "200 OK", app.state())
            await respond(w, "404 Not Found", {"error": "not found"})
        except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError):
            pass
        except Exception as e:
            log(f"erro no painel: {e}")
        finally:
            try:
                w.close()
            except Exception:
                pass

    server = await asyncio.start_server(handle, "127.0.0.1", port)
    return server


DASHBOARD_HTML = r"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kick Multiwatch</title>
<style>
:root{--bg:#1d1f3a;--bg2:#24274a;--panel:#3b2328;--panel2:#2c191d;--edge:#5c3a40;--ink:#f4ece6;--muted:#c2a9a6;
--purple:#6a46b8;--purple2:#8a63e0;--purple-ink:#fff;--gold:#f2b632;--gold-ink:#2b1a00;--green:#5fd38a;--red:#ff7a6e;
--live:#ff5f57;--chip:#4a2c32;--f-body:"Nunito","Segoe UI",system-ui,-apple-system,sans-serif;--f-mono:ui-monospace,Menlo,Consolas,monospace;color-scheme:dark}
*{box-sizing:border-box}[hidden]{display:none!important}html,body{height:100%}
body{margin:0;color:var(--ink);font:600 14px/1.45 var(--f-body);display:flex;flex-direction:column;
background-color:var(--bg);background-image:conic-gradient(var(--bg2) 25%,transparent 0 50%,var(--bg2) 0 75%,transparent 0);background-size:48px 48px}
a{color:var(--gold)}
.panel{background:var(--panel);border:2px solid var(--edge);border-radius:10px;box-shadow:inset 0 0 0 2px var(--panel2),0 3px 0 rgba(0,0,0,.35)}
h2,.lbl{font:800 12px var(--f-body);text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin:0}
button{font:800 13px var(--f-body);padding:7px 14px;border-radius:7px;border:2px solid var(--purple2);background:linear-gradient(var(--purple2),var(--purple));color:var(--purple-ink);cursor:pointer;box-shadow:0 2px 0 #2a1950}
button:hover{filter:brightness(1.1)}button:disabled{opacity:.5;cursor:default;filter:none}
button.gold{background:linear-gradient(#ffd35e,var(--gold));border-color:#ffd35e;color:var(--gold-ink);box-shadow:0 2px 0 #7a5200}
button.danger{background:linear-gradient(#e2554a,#b3352c);border-color:#f07067;box-shadow:0 2px 0 #5a1510}
button.flat{background:transparent;border-color:var(--edge);color:var(--muted);box-shadow:none}
button:focus-visible,input:focus-visible,select:focus-visible,.ch:focus-visible{outline:2px solid var(--gold);outline-offset:2px}
input,select{font:600 14px var(--f-body);padding:7px 10px;border:2px solid var(--edge);border-radius:7px;background:var(--panel2);color:var(--ink);min-width:0}
input[type=checkbox]{width:16px;height:16px;accent-color:var(--purple2)}
.bad{color:var(--red)}.ok{color:var(--green)}.muted{color:var(--muted)}
.note{font-size:12.5px;color:var(--muted);margin:0}
/* token gate */
#gate{flex:1;display:flex;align-items:center;justify-content:center;padding:16px}
#gate .panel{max-width:520px;width:100%;padding:22px;display:grid;gap:14px}
#gate h1{margin:0;font-size:22px;color:var(--gold)}
#gate ol{margin:0;padding-left:20px;display:grid;gap:4px;color:var(--muted)}
#gate form{display:flex;gap:8px}#gate form input{flex:1}
#gate label{display:flex;gap:8px;align-items:center;color:var(--muted)}
/* app */
#app{flex:1;display:flex;flex-direction:column;min-height:0;padding:10px;gap:10px}
header{display:flex;flex-wrap:wrap;gap:10px;align-items:stretch}
header .brand{display:flex;align-items:center;padding:0 14px;font-size:18px;font-weight:900;color:var(--gold)}
.stat{padding:8px 14px;min-width:120px;font-variant-numeric:tabular-nums}
.stat b{display:block;font-size:20px;line-height:1.2;font-weight:900}
.stat b.plus{color:var(--green)}.stat b.minus{color:var(--red)}
nav{display:flex;gap:8px;flex-wrap:wrap}
nav button{min-width:110px}nav button[aria-selected=true]{background:linear-gradient(#ffd35e,var(--gold));border-color:#ffd35e;color:var(--gold-ink);box-shadow:0 2px 0 #7a5200}
.view{flex:1;min-height:0}
#vCanais{display:grid;grid-template-columns:minmax(320px,460px) 1fr;gap:10px}
@media (max-width:820px){#vCanais{grid-template-columns:1fr;grid-template-rows:auto 55vh}.view{min-height:auto}}
#left{display:flex;flex-direction:column;min-height:0;overflow:auto;padding:10px;gap:8px}
#add{display:flex;gap:8px}#add input{flex:1}
#err{color:var(--red);font-size:13px}
.ch{display:grid;grid-template-columns:1fr auto;gap:4px 10px;padding:10px 12px;border-radius:8px;background:var(--panel2);border:2px solid transparent;cursor:pointer}
.ch.sel{border-color:var(--gold)}.ch.off{opacity:.6}
.name{font-weight:800;display:flex;gap:6px;align-items:center;flex-wrap:wrap;min-width:0}
.dot{width:9px;height:9px;border-radius:50%;flex:none}
.pill{font:800 10.5px var(--f-body);padding:1px 7px;border-radius:999px;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap;background:var(--chip);color:var(--muted)}
.pill.live{background:var(--live);color:#fff}.pill.watching{background:var(--green);color:#0d2a17}.pill.error{background:var(--red);color:#2a0805}
.pill.connecting{background:var(--gold);color:var(--gold-ink)}
.info{font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;font-weight:600}
.pts{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.pts b{font-size:18px;font-weight:900;color:var(--gold)}
.pts small{display:block;font-size:11.5px}
.ctl{display:flex;gap:4px;align-items:center;justify-content:flex-end}
.ctl button.ic{background:transparent;border:none;box-shadow:none;color:var(--muted);padding:2px 6px;font-size:15px}
.ctl button.ic:disabled{opacity:.25}
.ctl button.two{padding:0 7px;font-size:11px;background:transparent;border-color:var(--edge);color:var(--muted);box-shadow:none}
.ctl button.two.on{border-color:var(--gold);color:var(--gold)}
.sw{position:relative;width:36px;height:20px;border-radius:10px;background:var(--chip);border:2px solid var(--edge);padding:0;flex:none;box-shadow:none}
.sw::after{content:"";position:absolute;top:2px;left:2px;width:12px;height:12px;border-radius:50%;background:var(--muted);transition:left .15s}
.sw[aria-checked=true]{background:var(--purple);border-color:var(--purple2)}.sw[aria-checked=true]::after{left:18px;background:#fff}
.line2{grid-column:1/-1;font-size:12px}
#right{display:flex;flex-direction:column;min-height:0;min-width:0;padding:10px;gap:8px}
#tabs{display:flex;gap:6px;overflow-x:auto;flex:none;padding-bottom:2px}
#tabs button{padding:4px 10px;font-size:12px;white-space:nowrap;background:var(--panel2);border-color:var(--edge);color:var(--muted);box-shadow:none}
#tabs button.on{border-color:var(--gold);color:var(--gold)}
#chat{flex:1;overflow:auto;padding:8px 10px;font-size:13.5px;min-height:0;background:#141428;border:2px solid #3d3a6a;border-radius:8px}
#chat p{margin:0;padding:2px 0;overflow-wrap:anywhere;font-weight:600}
#chat .t{color:var(--muted);font:11px var(--f-mono);margin-right:6px}
#chat .c{font:800 11px var(--f-body);margin-right:6px}
#chat .emo{height:24px;vertical-align:middle}
.empty{color:var(--muted);padding:16px 4px}
/* resgates */
#vResgates,#vOpcoes{overflow:auto}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-bottom:10px}
.card{padding:12px 14px;background:var(--panel2);border-radius:8px}
.card b{display:block;font-size:24px;font-weight:900;font-variant-numeric:tabular-nums}
.box{padding:14px;display:grid;gap:10px;margin-bottom:10px;align-content:start}
table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}
th{font:800 11px var(--f-body);text-transform:uppercase;letter-spacing:.06em;color:var(--muted);text-align:left;padding:6px 8px;border-bottom:2px solid var(--edge)}
td{padding:7px 8px;border-bottom:1px solid var(--edge);vertical-align:top}
td.num,th.num{text-align:right;white-space:nowrap}
.tag{display:inline-block;background:var(--chip);border-radius:6px;padding:1px 7px;margin:1px 4px 1px 0;font-size:12.5px}
.tblwrap{overflow-x:auto}
/* opções */
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:10px}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.prices{display:grid;gap:6px}
.prices .row{flex-wrap:nowrap}.prices .row input.nm{flex:1 1 auto;width:0}.prices .row input.cost{width:90px;flex:none}
.confirm{background:var(--panel2);border:2px solid var(--red);border-radius:8px;padding:10px;display:grid;gap:8px}
</style></head><body>
<div id="gate" hidden></div>
<div id="app" hidden>
  <header>
    <div class="brand panel">Kick Multiwatch</div>
    <div class="stat panel"><span class="lbl">Conta</span><b id="sUser">…</b></div>
    <div class="stat panel"><span class="lbl">Saldo total</span><b id="sPts">–</b></div>
    <div class="stat panel"><span class="lbl">Ganhos na sessão</span><b id="sGain" class="plus">–</b></div>
    <div class="stat panel"><span class="lbl">Gastos na sessão</span><b id="sSpent" class="minus">–</b></div>
    <div class="stat panel"><span class="lbl">Ao vivo / ganhando</span><b id="sLive">0</b></div>
    <div class="stat panel"><span class="lbl">Conexão</span><b id="sConn">…</b></div>
  </header>
  <nav role="tablist">
    <button role="tab" data-view="Canais" aria-selected="true">Canais</button>
    <button role="tab" data-view="Resgates" aria-selected="false">Resgates</button>
    <button role="tab" data-view="Opcoes" aria-selected="false">Opções</button>
  </nav>
  <section id="vCanais" class="view">
    <div id="left" class="panel">
      <form id="add"><input id="slug" placeholder="Adicionar canal, ex.: gaules" autocomplete="off" aria-label="Nome do canal"><button>Adicionar</button></form>
      <div id="err" hidden></div>
      <div id="list"></div>
      <p class="note">O saldo é o que a Kick mostra no canal. Embaixo dele: <span class="ok">+ganhos</span> e <span class="bad">−gastos</span> desta sessão. A Kick credita 10 pontos a cada 5 min (20 se você for inscrito, marque 2×). “Na fila” é um canal ao vivo esperando a vez de ganhar.</p>
    </div>
    <div id="right" class="panel">
      <div id="tabs"></div>
      <div id="chat"></div>
    </div>
  </section>
  <section id="vResgates" class="view" hidden></section>
  <section id="vOpcoes" class="view" hidden></section>
</div>
<script>
const $=id=>document.getElementById(id);
const COLORS=["#ff6f61","#5fd38a","#f2b632","#5fa8ff","#c27bff","#3fd1d9","#ff9a4d","#9be35a","#ff6fb0","#8f94ff","#4fd6b8","#e0c25a"];
const STATE={watching:"ganhando",queued:"na fila",connecting:"conectando",error:"erro",paused:"pausado"};
let S={channels:[],account:{state:"loading"}},sel="",msgs=[],view="Canais",confirmReset=false,priceDraft=null;
const fmt=n=>n==null?"–":Number(n).toLocaleString("pt-BR");
const hhmm=t=>new Date(t*1000).toTimeString().slice(0,5);
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function api(method,path,body){
  const r=await fetch(path,{method,headers:{"Content-Type":"application/json","X-Kickwatch":"1"},body:body?JSON.stringify(body):undefined});
  const j=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(j.error||("Erro "+r.status));
  S=j;render();
}
function showErr(t){$("err").textContent=t;$("err").hidden=!t}
function render(){
  const A=S.account||{};
  const on=A.state==="connected";
  $("gate").hidden=on;$("app").hidden=!on;
  if(!on){renderGate();return}
  gateKey="";
  const ch=S.channels||[];
  $("sUser").textContent=S.user||"conectado";
  const known=ch.some(c=>c.points!=null);
  $("sPts").textContent=known?fmt(ch.reduce((a,c)=>a+(c.points||0),0)):"–";
  $("sGain").textContent=S.earned?"+"+fmt(S.earned):"0";
  $("sSpent").textContent=S.spent?"−"+fmt(S.spent):"0";
  $("sLive").textContent=ch.filter(c=>c.live).length+" / "+ch.filter(c=>c.watch==="watching").length;
  $("sConn").textContent=S.chat==="connected"?"online":S.chat==="reconnecting"?"reconectando":"conectando";
  renderList(ch);renderTabs(ch);
  if(view==="Resgates")renderResgates();
  if(view==="Opcoes")renderOpcoes();
}
function renderList(ch){
  const list=$("list");
  if(!ch.length){list.innerHTML='<p class="empty">Nenhum canal ainda. Adicione um acima.</p>';return}
  const ago=t=>{const m=Math.floor((Date.now()/1000-t)/60);return m<1?"agora":"há "+m+" min"};
  list.innerHTML=ch.map((c,i)=>{
    const st=!c.enabled?"paused":c.live?c.watch:"";
    const pill=c.live?'<span class="pill live">ao vivo</span>':'';
    const wp=STATE[st]?`<span class="pill ${st}">${STATE[st]}</span>`:"";
    const turn=c.in_turn&&c.turn_started?`ganhando há ${Math.floor((Date.now()/1000-c.turn_started)/60)} min · `:"";
    const last=c.last_credit?`últimos pontos ${ago(c.last_credit)} · `:"";
    const info=c.live?`${turn}${last}${fmt(c.viewers)} espectadores${c.category?" · "+esc(c.category):""} · ${esc(c.title)}`:`${last}offline`;
    const delta=(c.earned||c.spent)?`<small>${c.earned?`<span class="ok">+${fmt(c.earned)}</span>`:""}${c.earned&&c.spent?" · ":""}${c.spent?`<span class="bad">−${fmt(c.spent)}</span>`:""}</small>`:`<small class="muted">sem mudança</small>`;
    const warn=c.no_points?`<div class="line2" style="color:var(--gold)">Ganhando há mais de 12 min sem pontos novos. A Kick pode não estar creditando este canal.</div>`:"";
    return `<div class="ch ${c.slug===sel?"sel":""} ${c.live?"":"off"}" tabindex="0" data-sel="${c.slug}">
      <div class="name"><span class="dot" style="background:${COLORS[c.idx%COLORS.length]}"></span>${esc(c.slug)} ${pill} ${wp}</div>
      <div class="pts" title="Saldo atual neste canal"><b>${fmt(c.points)}</b>${delta}</div>
      <div class="info">${info}</div>
      <div class="ctl"><button class="two ${c.subscribed?"on":""}" title="Sou inscrito aqui (pontos em dobro)" aria-pressed="${c.subscribed}" data-sub="${c.slug}">2×</button><button class="ic" title="Subir" aria-label="Subir ${c.slug}" data-mv="up" data-slug="${c.slug}" ${i?"":"disabled"}>↑</button><button class="ic" title="Descer" aria-label="Descer ${c.slug}" data-mv="down" data-slug="${c.slug}" ${i<ch.length-1?"":"disabled"}>↓</button><button class="sw" role="switch" aria-checked="${c.enabled}" aria-label="Ganhar pontos em ${c.slug}" title="Ganhar pontos neste canal" data-sw="${c.slug}"></button><button class="ic" title="Remover" aria-label="Remover ${c.slug}" data-rm="${c.slug}">×</button></div>
      ${c.watch==="error"&&c.watch_error?`<div class="line2 bad">${esc(c.watch_error)}</div>`:""}${warn}</div>`}).join("");
}
function renderTabs(ch){
  $("tabs").innerHTML=[["","Todos"],...ch.map(c=>[c.slug,c.slug])].map(([s,l])=>`<button class="${s===sel?"on":""}" data-tab="${s}">${esc(l)}</button>`).join("");
}
function renderChat(){
  const box=$("chat"),stick=box.scrollTop+box.clientHeight>=box.scrollHeight-40;
  const shown=msgs.filter(m=>!sel||m.slug===sel).slice(-250);
  box.innerHTML=shown.length?shown.map(line).join(""):'<p class="empty">O chat dos seus canais aparece aqui.</p>';
  if(stick)box.scrollTop=box.scrollHeight;
}
function line(m){
  const tag=sel?"":`<span class="c" style="color:${COLORS[m.idx%COLORS.length]}">${esc(m.slug)}</span>`;
  const col=/^#[0-9a-f]{3,8}$/i.test(m.color)?m.color:"inherit";
  const txt=esc(m.text).replace(/\[emote:(\d+):([^\]\s]*)\]/g,(_,id,n)=>`<img class="emo" src="https://files.kick.com/emotes/${id}/fullsize" alt="${n}" title="${n}">`);
  return `<p><span class="t">${hhmm(m.ts)}</span>${tag}<b style="color:${col}">${esc(m.user)}</b>: ${txt}</p>`;
}
let gateKey="";
function renderGate(){
  const A=S.account||{},key=A.state+"|"+A.error;
  if(key===gateKey)return;gateKey=key;
  const g=$("gate");
  if(A.state==="loading"){g.innerHTML='<div class="panel"><h1>Kick Multiwatch</h1><p class="muted">Carregando…</p></div>';return}
  if(A.state==="checking"){g.innerHTML='<div class="panel"><h1>Kick Multiwatch</h1><p>Verificando seu token com a Kick…</p></div>';return}
  g.innerHTML=`<div class="panel">
    <h1>Kick Multiwatch</h1>
    <p>Para começar, conecte sua conta da Kick com o seu <b>token de sessão</b>. Sem ele o painel não funciona.</p>
    <ol><li>Entre em <a href="https://kick.com" target="_blank" rel="noopener">kick.com</a> neste navegador.</li>
    <li>Aperte F12 e abra Aplicativo (Armazenamento no Firefox), depois Cookies, depois https://kick.com.</li>
    <li>Copie o valor de <b>session_token</b> e cole abaixo.</li></ol>
    <form id="conn"><input id="tok" type="password" placeholder="Cole o session_token" autocomplete="off" aria-label="Token de sessão da Kick"><button class="gold">Conectar</button></form>
    <label><input type="checkbox" id="remember" checked> Lembrar neste computador (salvo em token.txt, ao lado do script)</label>
    ${A.state==="failed"&&A.error?`<p class="bad">${esc(A.error)}</p>`:""}
    <p class="note">O token fica só neste computador e só é enviado para a Kick. Trate-o como uma senha: quem tem o token entra na sua conta. Sair da conta em kick.com invalida o token.</p>
  </div>`;
  $("conn").onsubmit=async e=>{e.preventDefault();const t=$("tok").value.trim();if(!t)return;
    const b=e.target.querySelector("button");b.disabled=true;b.textContent="Verificando…";
    try{await api("POST","/api/connect",{token:t,remember:$("remember").checked})}catch(er){gateKey="";S.account={state:"failed",error:er.message};render()}};
}
let resKey="";
function renderResgates(){
  const L=S.spend_log||[],key=L.length+"|"+S.spent+"|"+S.earned+"|"+S.session_file;
  if(key===resKey)return;resKey=key;
  const known=L.filter(e=>e.known);
  const count={};known.forEach(e=>e.items.forEach(n=>count[n]=(count[n]||0)+1));
  const rows=L.slice().reverse().map(e=>`<tr><td>${hhmm(e.at)}</td><td>${esc(e.slug)}</td>
    <td>${e.known?e.items.map(n=>`<span class="tag">${esc(n)}</span>`).join(""):'<span class="muted">Gasto sem recompensa correspondente</span>'}</td>
    <td class="num bad">−${fmt(e.spent)}</td><td class="num muted">${fmt(e.before)} → ${fmt(e.after)}</td></tr>`).join("");
  $("vResgates").innerHTML=`<div class="cards">
      <div class="card panel"><span class="lbl">Resgates na sessão</span><b>${fmt(known.reduce((a,e)=>a+e.items.length,0))}</b></div>
      <div class="card panel"><span class="lbl">Pontos gastos</span><b class="bad">${S.spent?"−"+fmt(S.spent):"0"}</b></div>
      <div class="card panel"><span class="lbl">Pontos ganhos</span><b class="ok">${S.earned?"+"+fmt(S.earned):"0"}</b></div>
      <div class="card panel"><span class="lbl">Saldo da sessão</span><b>${(S.earned||0)-(S.spent||0)>=0?"+":"−"}${fmt(Math.abs((S.earned||0)-(S.spent||0)))}</b></div>
    </div>
    ${Object.keys(count).length?`<div class="box panel"><h2>Por recompensa</h2><div>${Object.entries(count).map(([n,k])=>`<span class="tag">${esc(n)} × ${k}</span>`).join("")}</div></div>`:""}
    <div class="box panel"><h2>Registro de resgates</h2>
    ${L.length?`<div class="tblwrap"><table><thead><tr><th>Hora</th><th>Canal</th><th>Recompensa</th><th class="num">Custo</th><th class="num">Saldo</th></tr></thead><tbody>${rows}</tbody></table></div>`:'<p class="empty">Nenhum resgate nesta sessão ainda. Quando você resgatar algo na Kick, a queda no saldo aparece aqui.</p>'}
    <p class="note">Os resgates são deduzidos da queda do saldo de cada canal, comparada com os preços das recompensas em Opções. O painel não resgata nada. ${S.session_file?`Esta sessão é salva em <b>sessoes/${esc(S.session_file)}</b>.`:"A sessão é salva na pasta sessoes/ quando o saldo mudar."}</p></div>`;
}
let optKey="";
function renderOpcoes(){
  const A=S.account||{};
  const key=[S.user,A.saved,S.max_earning,S.rotate_every,confirmReset,JSON.stringify(S.prices),priceDraft?1:0].join("|");
  const nr=$("nextrot");
  if(key===optKey){if(nr)nr.textContent=nextRot();return}
  optKey=key;
  const opt=(list,cur)=>list.map(([v,l])=>`<option value="${v}" ${v===cur?"selected":""}>${l}</option>`).join("");
  const P=priceDraft||S.prices||[];
  $("vOpcoes").innerHTML=`<div class="grid2">
    <div class="box panel"><h2>Conta</h2>
      <p>Conectado como <b class="ok">${esc(S.user||"?")}</b>. ${A.saved?"Token salvo em token.txt.":"Token só na memória (não salvo)."}</p>
      ${confirmReset?`<div class="confirm"><p style="margin:0">Remover o token e reiniciar a sessão? Isso apaga token.txt, zera ganhos, gastos e o registro de resgates desta sessão, e volta para a tela do token. O arquivo já salvo em sessoes/ continua lá.</p>
        <div class="row"><button class="danger" id="resetYes">Remover e reiniciar</button><button class="flat" id="resetNo">Cancelar</button></div></div>`
        :`<div class="row"><button class="danger" id="resetAsk">Remover token e reiniciar sessão</button></div>`}
    </div>
    <div class="box panel"><h2>Ganho de pontos</h2>
      <label class="row" for="maxe">Ganhar em <select id="maxe">${opt([[1,"1 canal"],[2,"2 canais (recomendado)"],[3,"3 canais"],[0,"todos os canais ao vivo"]],S.max_earning)}</select> por vez</label>
      <label class="row" for="rot">Trocar de canal <select id="rot" ${S.max_earning?"":"disabled"}>${opt([[-1,"a cada crédito (automático)"],[0,"nunca (topo da lista)"],[10,"a cada 10 min"],[15,"a cada 15 min"],[30,"a cada 30 min"],[60,"a cada hora"]],S.rotate_every)}</select></label>
      <p class="note">A Kick credita cerca de 2 canais a cada 5 minutos por conta. Canais 2× (inscrito) ganham primeiro; depois o topo da lista. <span id="nextrot">${nextRot()}</span></p>
    </div>
    <div class="box panel"><h2>Preços das recompensas</h2>
      <p class="note">Usados para reconhecer o que você resgatou a partir da queda do saldo. Vale para todos os canais.</p>
      <div class="prices">${P.map((p,i)=>`<div class="row"><input class="nm" data-pi="${i}" data-f="name" value="${esc(p.name)}" maxlength="60" aria-label="Nome da recompensa"><input class="cost" data-pi="${i}" data-f="cost" type="number" min="1" value="${p.cost}" aria-label="Custo em pontos"><button class="flat" data-pdel="${i}" title="Remover" aria-label="Remover recompensa">×</button></div>`).join("")}</div>
      <div class="row"><button class="flat" id="padd">+ Recompensa</button><button class="gold" id="psave" ${priceDraft?"":"disabled"}>Salvar preços</button>${priceDraft?'<button class="flat" id="pcancel">Descartar</button>':""}</div>
    </div>
    <div class="box panel"><h2>Aviso</h2>
      <p class="note">Usa endpoints internos e não documentados da Kick, que podem mudar a qualquer momento. Simular tempo assistido pode violar os Termos de Serviço da Kick e sua conta pode ser restringida. Use por sua conta e risco.</p>
    </div></div>`;
  const draft=()=>{if(!priceDraft)priceDraft=(S.prices||[]).map(p=>({...p}))};
  $("resetAsk")&&($("resetAsk").onclick=()=>{confirmReset=true;renderOpcoes()});
  $("resetNo")&&($("resetNo").onclick=()=>{confirmReset=false;renderOpcoes()});
  $("resetYes")&&($("resetYes").onclick=async()=>{confirmReset=false;priceDraft=null;show("Canais");
    try{await api("POST","/api/reset")}catch(e){alert(e.message)}});
  $("maxe").onchange=e=>api("POST","/api/settings",{max_earning:+e.target.value}).catch(er=>alert(er.message));
  $("rot").onchange=e=>api("POST","/api/settings",{rotate_every:+e.target.value}).catch(er=>alert(er.message));
  $("vOpcoes").querySelectorAll("[data-pi]").forEach(inp=>inp.oninput=()=>{const was=!!priceDraft;draft();
    const p=priceDraft[+inp.dataset.pi];p[inp.dataset.f]=inp.dataset.f==="cost"?+inp.value:inp.value;
    if(!was){$("psave").disabled=false;optKey=[S.user,A.saved,S.max_earning,S.rotate_every,confirmReset,JSON.stringify(S.prices),1].join("|")}});
  $("vOpcoes").querySelectorAll("[data-pdel]").forEach(b=>b.onclick=()=>{draft();priceDraft.splice(+b.dataset.pdel,1);renderOpcoes()});
  $("padd").onclick=()=>{draft();priceDraft.push({name:"Nova recompensa",cost:100});renderOpcoes()};
  $("pcancel")&&($("pcancel").onclick=()=>{priceDraft=null;renderOpcoes()});
  $("psave").onclick=async()=>{const p=priceDraft;priceDraft=null;
    try{await api("POST","/api/settings",{prices:p})}catch(e){priceDraft=p;alert(e.message)}};
}
function nextRot(){
  if(!S.max_earning)return"";
  if(S.rotate_every===-1)return"Quando um canal recebe os pontos, a vaga vai para o canal que espera há mais tempo (ou após 7 min sem pontos).";
  if(S.next_rotation&&S.rotate_every>0)return"Próxima troca em "+Math.max(0,Math.round((S.next_rotation-Date.now()/1000)/60))+" min.";
  return"";
}
function show(v){view=v;document.querySelectorAll("nav button").forEach(b=>b.setAttribute("aria-selected",b.dataset.view===v));
  ["Canais","Resgates","Opcoes"].forEach(x=>$("v"+x).hidden=x!==v);resKey=optKey="";render()}
function select(s){sel=s;render();renderChat()}
document.addEventListener("click",async e=>{
  const t=e.target.closest("[data-view],[data-sub],[data-mv],[data-rm],[data-sw],[data-tab],[data-sel]");if(!t)return;
  try{
    if(t.dataset.view){show(t.dataset.view);return}
    if(t.dataset.sub){e.stopPropagation();await api("POST","/api/channels/"+t.dataset.sub+"/sub",{on:t.getAttribute("aria-pressed")!=="true"});return}
    if(t.dataset.mv){e.stopPropagation();await api("POST","/api/channels/"+t.dataset.slug+"/"+t.dataset.mv);return}
    if(t.dataset.rm){e.stopPropagation();if(sel===t.dataset.rm)sel="";await api("DELETE","/api/channels/"+t.dataset.rm)}
    else if(t.dataset.sw){e.stopPropagation();await api("POST","/api/channels/"+t.dataset.sw+"/watch",{on:t.getAttribute("aria-checked")!=="true"})}
    else if(t.dataset.tab!==undefined)select(t.dataset.tab);
    else if(t.dataset.sel)select(sel===t.dataset.sel?"":t.dataset.sel);
  }catch(err){showErr(err.message)}
});
document.addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.dataset&&e.target.dataset.sel)e.target.click()});
$("add").addEventListener("submit",async e=>{
  e.preventDefault();const v=$("slug").value.trim();if(!v)return;
  const b=e.target.querySelector("button");b.disabled=true;b.textContent="Adicionando…";showErr("");
  try{await api("POST","/api/channels",{slug:v});$("slug").value=""}catch(err){showErr(err.message)}
  b.disabled=false;b.textContent="Adicionar";
});
function connect(){
  const es=new EventSource("/events");
  es.addEventListener("state",e=>{S=JSON.parse(e.data);render()});
  es.addEventListener("backlog",e=>{msgs=JSON.parse(e.data);renderChat()});
  let pending=false;
  es.addEventListener("chat",e=>{msgs.push(JSON.parse(e.data));if(msgs.length>2000)msgs=msgs.slice(-1000);
    if(!pending){pending=true;requestAnimationFrame(()=>{pending=false;renderChat()})}});
  es.onerror=()=>{const c=$("sConn");if(c)c.textContent="script parado?"};
}
render();renderChat();connect();
</script></body></html>
"""


async def main():
    ap = argparse.ArgumentParser(description="Follow many Kick channels with no video.")
    ap.add_argument("channels", nargs="*", help="channel slugs, e.g. xqc adinross")
    ap.add_argument("-f", "--file", help="text file with one channel slug per line (saved when you add or remove channels)")
    ap.add_argument("--port", type=int, default=8787, help="dashboard port (default 8787)")
    ap.add_argument("--no-dashboard", action="store_true", help="do not start the local dashboard")
    ap.add_argument("--no-open", action="store_true", help="do not open the dashboard in a browser")
    ap.add_argument("--print-chat", action="store_true", help="also print chat in the terminal")
    ap.add_argument("--no-chat", action="store_true", help=argparse.SUPPRESS)  # old flag, now the default
    ap.add_argument("--status-every", type=int, default=300, help="seconds between terminal status tables")
    args = ap.parse_args()

    slugs = list(args.channels)
    path = args.file
    if path and os.path.exists(path):
        with open(path) as f:
            slugs += [s for s in f if s.strip() and not s.lstrip().startswith("#")]
    slugs = list(dict.fromkeys(filter(None, map(clean_slug, slugs))))
    if not slugs and args.no_dashboard:
        ap.error("give at least one channel")
    if not path and not args.channels:
        path = "channels.txt"

    token = os.environ.get("KICK_SESSION_TOKEN", "").strip()
    if not token and os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE) as f:
            token = f.readline().strip()
    kick = Kick(None)
    app = App(kick, path, args.print_chat)

    if not args.no_dashboard:
        try:
            await serve_dashboard(app, args.port)
        except OSError as e:
            sys.exit(f"não consegui abrir o painel na porta {args.port} ({e}). "
                     f"O kickwatch já está rodando? Tente --port {args.port + 1}.")
        url = f"http://127.0.0.1:{args.port}"
        log(f"painel: {url}")
        if not args.no_open:
            try:
                webbrowser.open(url)
            except Exception:
                pass

    if token:
        app.account = {"state": "checking", "error": "", "saved": True}
    log(f"carregando {len(slugs)} canais...")
    for s in slugs:
        try:
            await app.add(s, save=False)
        except LookupError:
            log(f"{s}: não encontrado, ignorando")
        except Exception as e:
            log(f"{s}: {e}")
        await asyncio.sleep(0.3)
    if not app.channels and args.no_dashboard:
        sys.exit("nenhum canal carregado; a Kick pode estar bloqueando esta rede")

    # Connection phase: a saved token is checked with Kick before any earning.
    if token:
        log("verificando o token salvo...")
        await app.connect(token)
    else:
        log("nenhuma conta conectada; informe o token de sessão no painel.")

    await asyncio.gather(app.chat_loop(), app.poll_loop(), app.points_loop(), app.rotate_loop(),
                         app.tick_loop(), app.status_loop(args.status_every))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
