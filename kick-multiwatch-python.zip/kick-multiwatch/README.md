# kickwatch

Follow many Kick channels at once without video. One Python process, roughly 40 to 60 MB of RAM no matter how many channels.

## Run

Easiest: download the zip from the Kick Multiwatch page, then run `start.bat` (Windows) or `sh start.sh` (Mac/Linux). The launcher creates its own `.venv` and installs everything.

Manual:

```
python -m venv .venv
.venv/bin/pip install websockets curl_cffi
.venv/bin/python kickwatch.py -f channels.txt
```

A dashboard (in Portuguese) opens at http://127.0.0.1:8787. On first open it asks for your Kick `session_token`; nothing else is usable until Kick accepts it. Then it has three tabs:

- **Canais**: balance per channel, with this session's earned (+) and spent (−) shown separately under it, 2× / priority arrows / pause switch / remove, and chat.
- **Resgates**: a per-session log of rewards you redeemed on kick.com. The script never redeems anything; it infers each redemption from a drop in a channel's balance, matched against the reward prices (up to 3 rewards per drop, and a +10/+20 watch credit landing in the same check is allowed for). A drop that matches nothing is listed as "Gasto sem recompensa correspondente".
- **Opções**: "Remover token e reiniciar sessão" (deletes token.txt, zeroes the session and returns to the token screen), how many channels earn at once, rotation, and the editable reward price list (defaults: 300, 500, 1000).

Each session is written to `sessoes/sessao-YYYY-mm-dd_HH-MM-SS.json` next to the script (balances, earned, spent, redemptions) whenever a balance changes. Settings, including prices, are in `settings.json`. Changes to channels are saved to `channels.txt`. The dashboard only listens on your own computer. Closing the browser tab doesn't stop the watcher; close the terminal or press Ctrl+C for that.

Options: `--port 8788`, `--no-open` (don't open a browser), `--no-dashboard`, `--print-chat` (also print chat in the terminal).

## Channel points (optional, at your own risk)

Kick credits points (10 per 5 min, 20 if subscribed) from watch-tracking events the player sends over `websockets.kick.com/viewer/v1`. The script sends the same events, at the same ~10 second cadence, once your account is connected.

The dashboard's token screen asks for your `session_token` (kick.com, F12, Application, Cookies). The script checks it with Kick first and only starts earning if Kick accepts it. "Lembrar" saves it in `token.txt` (readable only by you); next start it is checked again automatically. `KICK_SESSION_TOKEN` in the environment also works.

The token stays on your machine. Treat it like a password. Logging out of kick.com invalidates it.

Kick credits about 2 channels per 5 minutes per account, however many you watch (Gabriel's 42-minute log with 8 live channels showed exactly 2 credits of +10 every ~5 minutes). So by default only the top 2 live channels in your list send the watch signal; the rest show as "queued". Channels marked 2× (you are subscribed there, so Kick pays 20 per 5 min instead of 10) always earn first; the script also tries to detect this from Kick. After those, the top of your list earns; reorder with the arrows. "Switch to the next channels" defaults to **after each credit (auto)**: as soon as an earning channel's points land (balances of earning channels are checked every 30 s), its slot goes to the live channel that has waited longest since its last turn, so every live channel keeps getting fresh credits. A slot with no points after 7 minutes is handed on too. Fixed timers (10/15/30/60 min) and "never" (top of your list) are still available. Settings are saved in `settings.json` next to the script.

## Limits

- Uses Kick's internal, undocumented endpoints (the official public API has no chat-read, points or watch-time endpoints). They can change any time; Kick already rotated the chat key once (2026-10-13), which the script now looks up on every connect.
- Points balance comes from `kick.com/api/v2/channels/{name}/points` and refreshes every 2 minutes.
- The 2-channel limit is observed, not documented by Kick; other public Kick miners also cap it per account (`max_concurrent`, examples use 1 or 2). The only way past it is more accounts, which this script deliberately does not support (ban risk). Rotation, priority and 2× were tested only against a local mock.
- Automating watch time may break Kick's Terms of Service, and inflates viewer counts. Your account could be restricted.
