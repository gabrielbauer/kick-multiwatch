// Kick Multiwatch (extension): earns Kick channel points on several channels
// using the kick.com login already in this browser. Port of kickwatch.py:
// same endpoints, same viewer-socket protocol, same earning-slot rotation.
// The session token is read from the kick.com cookie on every call; it is
// never stored, logged or sent anywhere but Kick.
const api = globalThis.browser || globalThis.chrome;

const CLIENT_TOKEN = "e1393935a959b4020a4491574f6490129f678acdaa92760471263db43487f823";
const CHANNEL_URL = (s) => `https://kick.com/api/v2/channels/${s}`;
const POINTS_URL = (s) => `https://kick.com/api/v2/channels/${s}/points`;
const ME_URL = (s) => `https://kick.com/api/v2/channels/${s}/me`;
const USER_URL = "https://kick.com/api/v1/user";
const VIEWER_TOKEN_URL = "https://websockets.kick.com/viewer/v1/token";
const VIEWER_WS_URL = "wss://websockets.kick.com/viewer/v1/connect?token=";

const WATCH_EVERY = [9.5, 12.5];   // seconds, same cadence as the kick.com player
const HANDSHAKE_EVERY = [25, 35];
const REFRESH_EVERY = 120;         // channel live state
const POINTS_EVERY = 120;          // balance of channels not earning
const FAST_POINTS = 30;            // balance of earning channels
const TURN_GRACE = 7 * 60;         // auto mode: hand the slot on after this without credit
const AUTO = -1;
const DEFAULT_PRICES = [{ name: "Recompensa 300", cost: 300 }, { name: "Recompensa 500", cost: 500 },
                        { name: "Recompensa 1000", cost: 1000 }];

const t = () => Date.now() / 1000;
const rand = ([a, b]) => (a + Math.random() * (b - a)) * 1000;

function fresh() {
  return {
    v: 1, channels: [], next_idx: 0, subs: [], max_earning: 2, rotate_every: AUTO, rot_offset: 0,
    next_rotation: null, prices: DEFAULT_PRICES.map((p) => ({ ...p })), spend_log: [], started: t(),
    user: null, account: { state: "loading", error: "" }, paused: false, log: [],
    sw: { starts: 0, last_alive: 0, resumes: 0, max_gap: 0 },
  };
}

function freshChannel(slug, idx) {
  return {
    slug, idx, channel_id: null, user_id: null, livestream_id: null, title: "", viewers: 0, category: "",
    refreshed_at: 0, enabled: true, points: null, points_start: null, points_at: 0, earned: 0, spent: 0,
    last_credit: null, in_turn: false, turn_started: null, last_turn: 0, events_sent: 0, last_event: null,
    watch: "idle", watch_error: "", watching_since: null, sub_checked: false,
  };
}

let S = fresh();
const RT = new Map();        // slug -> live socket runtime (not persisted)
let saveTimer = null, ready = null, checking = null;

const ch = (slug) => S.channels.find((c) => c.slug === slug);
const live = (c) => c.livestream_id !== null && c.livestream_id !== undefined;
const isSub = (c) => S.subs.includes(c.slug);

function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flush, 400);
}
function flush() {
  clearTimeout(saveTimer);
  S.sw.last_alive = t();
  return api.storage.local.set({ st: S });
}
function log(msg) {
  S.log.unshift(`${new Date().toLocaleTimeString("pt-BR")} ${msg}`);
  S.log.length = Math.min(S.log.length, 100);
  persist();
}

function findKey(o, ...keys) {
  if (Array.isArray(o)) {
    for (const v of o) { const r = findKey(v, ...keys); if (r !== null) return r; }
  } else if (o && typeof o === "object") {
    for (const k of keys) if (k in o && o[k] !== null && typeof o[k] !== "object") return o[k];
    return findKey(Object.values(o), ...keys);
  }
  return null;
}

function cleanSlug(s) {
  return String(s || "").trim().replace(/^https?:\/\/(www\.)?kick\.com\//i, "").split(/[/?#\s]/)[0].toLowerCase();
}

// ---- Kick access --------------------------------------------------------
async function sessionToken() {
  const c = await api.cookies.get({ url: "https://kick.com/", name: "session_token" });
  return c && c.value ? decodeURIComponent(c.value) : null;
}

async function kfetch(url, { auth = true, extra = {} } = {}) {
  const h = { Accept: "application/json", ...extra };
  if (auth) {
    const tok = await sessionToken();
    if (!tok) return { status: 401, body: null, err: "sem login" };
    h.Authorization = "Bearer " + tok;
    h["X-Client-Token"] = CLIENT_TOKEN;
  }
  try {
    const r = await fetch(url, { headers: h, credentials: "include", cache: "no-store" });
    let body = null;
    try { body = await r.json(); } catch {}
    return { status: r.status, body };
  } catch (e) {
    return { status: 0, body: null, err: String(e.message || e) };
  }
}

const httpErr = (r) => r.status === 403 ? "bloqueado pela Kick/Cloudflare (403)" : r.status === 401 ? "a Kick recusou o login (401)"
  : r.status === 0 ? `sem conexão (${r.err || "rede"})` : `HTTP ${r.status}`;

// ---- account (browser login) ---------------------------------------------
let checkedAt = 0;
async function checkAccount(force = true) {
  // Routine checks only re-ask Kick every 5 min; cookie changes and 401s force one.
  if (!force && S.account.state === "connected" && t() - checkedAt < 300) return;
  if (checking) return checking;
  checkedAt = t();
  checking = (async () => {
    const tok = await sessionToken();
    if (!tok) return setAccount("nologin", "");
    if (S.account.state !== "connected") { S.account = { state: "checking", error: "" }; persist(); }
    const r = await kfetch(USER_URL);
    const name = findKey(r.body, "username");
    if (r.status === 200 && name) {
      const was = S.account.state === "connected";
      S.user = name;
      setAccount("connected", "");
      if (!was) {
        log(`conectado como ${name} (login do navegador)`);
        for (const c of S.channels) { c.sub_checked = false; updatePoints(c); }
      }
    } else if (r.status === 401 || r.status === 200) {
      setAccount("nologin", "Sua sessão da Kick expirou. Entre de novo em kick.com.");
    } else if (S.account.state !== "connected") {
      setAccount("failed", `Não consegui falar com a Kick: ${httpErr(r)}. Tentando de novo em 30 s.`);
    }
  })().finally(() => { checking = null; });
  return checking;
}

function setAccount(state, error) {
  const before = S.account.state;
  S.account = { state, error };
  if (state !== "connected") {
    if (before === "connected") log("conta desconectada: " + (error || "sem login em kick.com"));
    S.user = state === "nologin" ? null : S.user;
    stopAll();
  }
  rebalance();
  persist();
}

const earningOn = () => S.account.state === "connected" && !S.paused;

// ---- channels -------------------------------------------------------------
async function refresh(c) {
  const r = await kfetch(CHANNEL_URL(c.slug), { auth: false });
  if (r.status === 404) throw new Error("canal não encontrado");
  if (r.status !== 200 || !r.body) throw new Error(httpErr(r));
  const d = r.body, ls = d.livestream;
  const wasLive = live(c), oldLs = c.livestream_id;
  c.channel_id = d.id;
  c.user_id = d.user_id || (d.user || {}).id || null;
  if (ls && ls.is_live !== false) {
    c.livestream_id = ls.id;
    c.title = (ls.session_title || "").trim();
    c.viewers = ls.viewer_count || 0;
    const cats = ls.categories || [];
    c.category = cats.length ? (cats[0] || {}).name || "" : "";
  } else {
    c.livestream_id = null; c.viewers = 0;
  }
  const first = !c.refreshed_at;
  c.refreshed_at = t();
  if (!first && wasLive !== live(c)) log(`${c.slug} ${live(c) ? "entrou ao vivo" : "ficou offline"}`);
  return wasLive !== live(c) || oldLs !== c.livestream_id;
}

async function addChannel(raw) {
  const slug = cleanSlug(raw);
  if (!/^[a-z0-9_-]{1,40}$/.test(slug)) throw new Error("Nome de canal inválido.");
  if (ch(slug)) return;
  const c = freshChannel(slug, S.next_idx);
  await refresh(c);
  S.next_idx++;
  S.channels.push(c);
  log(`${slug} adicionado${live(c) ? " (AO VIVO)" : ""}`);
  rebalance();
  persist();
  updatePoints(c);
  detectSub(c);
}

function removeChannel(slug) {
  closeWatch(slug);
  S.channels = S.channels.filter((c) => c.slug !== slug);
  S.subs = S.subs.filter((s) => s !== slug);
  log(`${slug} removido`);
  rebalance();
}

function move(slug, delta) {
  const i = S.channels.findIndex((c) => c.slug === slug);
  if (i < 0) return;
  const j = Math.max(0, Math.min(S.channels.length - 1, i + delta));
  S.channels.splice(j, 0, S.channels.splice(i, 1)[0]);
  rebalance();
}

// ---- points, credits, redemptions ----------------------------------------
function matchSpend(drop, prices) {
  const costs = prices.filter((p) => p.cost > 0);
  for (const extra of [0, 10, 20]) {
    const target = drop + extra;
    for (const n of [1, 2, 3]) {
      const found = (function pick(start, left, k) {
        if (k === 0) return left === 0 ? [] : null;
        for (let i = start; i < costs.length; i++) {
          if (costs[i].cost > left) continue;
          const rest = pick(i, left - costs[i].cost, k - 1);
          if (rest) return [costs[i].name, ...rest];
        }
        return null;
      })(0, target, n);
      if (found) return { names: found, extra };
    }
  }
  return { names: null, extra: 0 };
}

function recordSpend(c, before, after) {
  const drop = before - after;
  const { names, extra } = matchSpend(drop, S.prices);
  if (extra) c.earned += extra;      // a watch credit landed in the same check
  const spent = drop + extra;
  c.spent += spent;
  S.spend_log.push({ at: t(), slug: c.slug, spent, before, after, items: names || [], known: !!names });
  S.spend_log = S.spend_log.slice(-500);
  log(`${c.slug} resgate: ${names ? names.join(" + ") : "gasto sem recompensa correspondente"} (−${spent})`);
}

async function updatePoints(c) {
  if (S.account.state !== "connected" || c.updating) return;
  c.updating = true;
  try {
    const r = await kfetch(POINTS_URL(c.slug));
    if (r.status === 401) { checkAccount(); return; }
    const raw = findKey(r.body, "points", "balance");
    const p = raw === null || raw === "" ? NaN : Number(raw);
    c.points_at = t();
    if (r.status !== 200 || !Number.isFinite(p)) return;
    // The first good reading is only the baseline, never a credit.
    if (c.points === null) { c.points = c.points_start = p; persist(); return; }
    const before = c.points;
    if (p > before) {
      c.earned += p - before;
      c.last_credit = t();
      log(`${c.slug} +${p - before} pontos (saldo ${p})`);
    } else if (p < before) {
      recordSpend(c, before, p);
    }
    c.points = p;
    if (p > before && !isSub(c)) endTurn(c, "recebeu os pontos");
    persist();
  } finally {
    c.updating = false;
  }
}

async function detectSub(c) {
  if (S.account.state !== "connected" || c.sub_checked) return;
  c.sub_checked = true;
  const r = await kfetch(ME_URL(c.slug));
  const d = r.body;
  if (r.status === 200 && d && (d.subscription || d.is_subscribed === true) && !isSub(c)) {
    S.subs.push(c.slug);
    log(`${c.slug}: você é inscrito aqui, ganha primeiro (pontos em dobro)`);
    rebalance();
  }
}

// ---- earning slots (same rules as kickwatch.py) ---------------------------
const eligible = (c) => earningOn() && c.enabled && live(c);

function wanted() {
  const cands = S.channels.filter(eligible);
  if (!S.max_earning) return cands;
  const subs = cands.filter(isSub);
  let rest = cands.filter((c) => !isSub(c));
  if (S.rotate_every === AUTO) {
    const slots = Math.max(0, S.max_earning - subs.length);
    const keep = rest.filter((c) => c.in_turn).slice(0, slots);
    const order = new Map(S.channels.map((c, i) => [c.slug, i]));
    const waiting = rest.filter((c) => !keep.includes(c))
      .sort((a, b) => (a.last_turn - b.last_turn) || (order.get(a.slug) - order.get(b.slug)));
    rest = keep.concat(waiting);
  } else if (S.rotate_every > 0 && rest.length) {
    const k = S.rot_offset % rest.length;
    rest = rest.slice(k).concat(rest.slice(0, k));
  }
  return subs.concat(rest).slice(0, S.max_earning);
}

function rebalance() {
  const want = new Set(wanted().map((c) => c.slug));
  for (const c of S.channels) {
    if (want.has(c.slug)) {
      if (!c.in_turn) { c.in_turn = true; c.turn_started = t(); }
      if (!RT.has(c.slug)) openWatch(c);
    } else {
      if (c.in_turn) { c.in_turn = false; c.last_turn = t(); }
      closeWatch(c.slug);
      c.watch = eligible(c) ? "queued" : "idle";
      c.watch_error = "";
      c.watching_since = null;
    }
  }
  persist();
}

function endTurn(c, why) {
  if (!c.in_turn) return;
  c.in_turn = false; c.last_turn = t();
  if (S.rotate_every === AUTO && S.max_earning) {
    rebalance();
    const nxt = wanted().filter((x) => x.in_turn && x !== c).map((x) => x.slug);
    log(`${c.slug} ${why}; agora ganhando em ${nxt.join(", ") || "nenhum outro"}`);
  }
}

function rotateCheck() {
  if (!(S.rotate_every && S.max_earning && earningOn())) return;
  if (S.rotate_every === AUTO) {
    for (const c of S.channels) {
      if (c.in_turn && !isSub(c) && c.turn_started && t() - c.turn_started > TURN_GRACE) {
        endTurn(c, `sem pontos após ${TURN_GRACE / 60} min`);
      }
    }
    return;
  }
  if (S.next_rotation === null) S.next_rotation = t() + S.rotate_every * 60;
  if (t() >= S.next_rotation) {
    const liveSubs = S.channels.filter((c) => eligible(c) && isSub(c)).length;
    S.rot_offset += Math.max(1, S.max_earning - liveSubs);
    S.next_rotation = t() + S.rotate_every * 60;
    rebalance();
    log(`rodízio: agora ganhando em ${wanted().map((c) => c.slug).join(", ") || "nenhum ao vivo"}`);
  }
}

// ---- viewer sockets ---------------------------------------------------------
function closeWatch(slug) {
  const rt = RT.get(slug);
  if (!rt) return;
  rt.closed = true;
  clearTimeout(rt.hs); clearTimeout(rt.ev); clearTimeout(rt.retry);
  if (rt.ws) { rt.ws.onclose = null; try { rt.ws.close(); } catch {} }
  RT.delete(slug);
}

function stopAll() {
  for (const slug of [...RT.keys()]) closeWatch(slug);
  for (const c of S.channels) {
    c.watch = "idle"; c.watching_since = null;
    if (c.in_turn) { c.in_turn = false; c.last_turn = t(); }
  }
}

function openWatch(c) {
  const rt = { ws: null, hs: null, ev: null, retry: null, backoff: 5000, closed: false };
  RT.set(c.slug, rt);
  connectWatch(c.slug, rt);
}

function retryWatch(slug, rt, why, delay) {
  if (rt.closed) return;
  const c = ch(slug);
  if (c) { c.watch = "error"; c.watch_error = why; persist(); }
  rt.retry = setTimeout(() => connectWatch(slug, rt), delay ?? rt.backoff);
  rt.backoff = Math.min(rt.backoff * 2, 120000);
}

async function connectWatch(slug, rt) {
  const c = ch(slug);
  if (rt.closed || !c || !eligible(c)) return;
  c.watch = "connecting"; persist();
  const r = await kfetch(VIEWER_TOKEN_URL, { extra: {
    "X-Chatroom": String(c.channel_id), "X-User-Id": String(c.user_id || c.channel_id) } });
  if (rt.closed) return;
  if (r.status === 401) { checkAccount(); return retryWatch(slug, rt, "a Kick recusou o login", 60000); }
  const vt = findKey(r.body, "token", "websocket_token");
  if (!vt) return retryWatch(slug, rt, `token de espectador recusado (${httpErr(r)})`);
  let ws;
  try { ws = new WebSocket(VIEWER_WS_URL + encodeURIComponent(vt)); }
  catch (e) { return retryWatch(slug, rt, "conexão falhou: " + e.message); }
  rt.ws = ws;
  const send = (o) => { if (ws.readyState === 1) ws.send(typeof o === "string" ? o : JSON.stringify(o)); };
  const handshake = () => {
    const x = ch(slug);
    if (!x || rt.closed) return;
    send({ type: "channel_handshake", data: { message: { channelId: Number(x.channel_id) } } });
    send('{"type":"ping"}');
    rt.hs = setTimeout(handshake, rand(HANDSHAKE_EVERY));
  };
  const watch = () => {
    const x = ch(slug);
    if (!x || rt.closed || !live(x)) return;
    send({ type: "user_event", data: { message: { name: "tracking.user.watch.livestream",
      channel_id: Number(x.channel_id), livestream_id: Number(x.livestream_id) } } });
    x.events_sent++; x.last_event = t();
    persist();
    rt.ev = setTimeout(watch, rand(WATCH_EVERY));
  };
  ws.onopen = () => {
    const x = ch(slug);
    if (!x || rt.closed) { try { ws.close(); } catch {} return; }
    x.watch = "watching"; x.watch_error = "";
    x.watching_since = x.watching_since || t();
    rt.backoff = 5000;
    persist();
    handshake(); watch();
  };
  ws.onmessage = (e) => {
    const m = String(e.data);
    if (m === "ping" || /"type"\s*:\s*"ping"/.test(m)) send('{"type":"pong"}');
  };
  ws.onclose = (e) => {
    clearTimeout(rt.hs); clearTimeout(rt.ev);
    rt.ws = null;
    retryWatch(slug, rt, `conexão caiu (código ${e.code})`);
  };
}

// ---- background loop ---------------------------------------------------------
let ticking = false;
async function tick() {
  if (ticking) return;
  ticking = true;
  try {
    await checkAccount(false);
    let changed = false;
    for (const c of S.channels) {
      if (t() - c.refreshed_at >= REFRESH_EVERY) {
        try { changed = (await refresh(c)) || changed; } catch (e) { c.refreshed_at = t(); }
      }
    }
    if (changed) rebalance();
    if (S.account.state === "connected") {
      for (const c of S.channels) {
        const due = c.in_turn ? FAST_POINTS : POINTS_EVERY;
        if (t() - c.points_at >= due - 2) await updatePoints(c);
        if (!c.sub_checked) detectSub(c);
      }
    }
    rotateCheck();
    // Sockets lost while the worker slept are reopened here.
    for (const c of S.channels) if (c.in_turn && !RT.has(c.slug) && eligible(c)) openWatch(c);
    persist();
  } finally {
    ticking = false;
  }
}

async function init() {
  const { st } = await api.storage.local.get("st");
  if (st && st.v === 1) {
    S = { ...fresh(), ...st, account: { state: "loading", error: "" } };
    for (const c of S.channels) {
      Object.assign(c, { ...freshChannel(c.slug, c.idx), ...c, updating: false, watch: c.in_turn ? "connecting" : c.watch });
    }
  }
  // A restart while earning means the browser stopped the worker.
  const gap = S.sw.last_alive ? t() - S.sw.last_alive : 0;
  if (S.sw.starts && S.channels.some((c) => c.in_turn) && gap > 20) {
    S.sw.resumes++; S.sw.max_gap = Math.max(S.sw.max_gap, Math.round(gap));
  }
  S.sw.starts++;
  await flush();
  api.alarms.create("tick", { periodInMinutes: 0.5 });
  await checkAccount();
  rebalance();
  tick();
}

api.alarms.onAlarm.addListener((a) => { if (a.name === "tick") ready.then(tick); });
api.runtime.onStartup.addListener(() => {});
setInterval(() => ready.then(tick), 15000);

api.cookies.onChanged.addListener((info) => {
  if (info.cookie.name === "session_token" && /(^|\.)kick\.com$/.test(info.cookie.domain.replace(/^\./, ""))) {
    ready.then(() => checkAccount());
  }
});

// The toolbar button opens (or focuses) the dashboard tab.
let panelTab = null;
api.action.onClicked.addListener(async () => {
  if (panelTab !== null) {
    try { await api.tabs.update(panelTab, { active: true }); return; } catch {}
  }
  const tab = await api.tabs.create({ url: api.runtime.getURL("painel.html") });
  panelTab = tab.id;
});
api.runtime.onConnect.addListener((port) => {
  // The dashboard keeps a port open; in Firefox this also keeps the background alive.
  if (port.sender && port.sender.tab) panelTab = port.sender.tab.id;
  port.onMessage.addListener(() => {});
});

function sessionExport() {
  return {
    inicio: new Date(S.started * 1000).toISOString(), conta: S.user,
    ganhos: S.channels.reduce((a, c) => a + c.earned, 0), gastos: S.channels.reduce((a, c) => a + c.spent, 0),
    canais: Object.fromEntries(S.channels.map((c) => [c.slug, { saldo: c.points, ganhos: c.earned, gastos: c.spent }])),
    resgates: S.spend_log.map((e) => ({ ...e, at: new Date(e.at * 1000).toISOString() })),
  };
}

function cleanPrices(raw) {
  const out = [];
  for (const p of raw || []) {
    const name = String((p && p.name) || "").trim().slice(0, 60), cost = Math.floor(Number(p && p.cost));
    if (name && cost > 0 && cost <= 1e7) out.push({ name, cost });
  }
  return out.slice(0, 20);
}

const handlers = {
  async add(m) { await addChannel(m.slug); },
  remove(m) { removeChannel(m.slug); },
  move(m) { move(m.slug, m.delta); },
  enable(m) { const c = ch(m.slug); if (c) { c.enabled = !!m.on; rebalance(); } },
  sub(m) {
    S.subs = S.subs.filter((s) => s !== m.slug);
    if (m.on && ch(m.slug)) S.subs.push(m.slug);
    rebalance();
  },
  settings(m) {
    if (m.prices !== undefined) S.prices = cleanPrices(m.prices);
    if (m.max_earning !== undefined) S.max_earning = Math.max(0, Math.floor(m.max_earning) || 0);
    if (m.rotate_every !== undefined) {
      S.rotate_every = Math.max(AUTO, Math.floor(m.rotate_every) || 0);
      S.next_rotation = S.rotate_every > 0 ? t() + S.rotate_every * 60 : null;
    }
    rebalance();
  },
  pause(m) { S.paused = !!m.on; if (S.paused) stopAll(); rebalance(); log(S.paused ? "pausado" : "retomado"); },
  async recheck() { await checkAccount(); rebalance(); },
  resetSession() {
    for (const c of S.channels) {
      Object.assign(c, { points: null, points_start: null, points_at: 0, earned: 0, spent: 0, last_credit: null,
                         events_sent: 0, last_event: null, turn_started: c.in_turn ? t() : null, last_turn: 0 });
      updatePoints(c);
    }
    S.spend_log = []; S.started = t(); S.log = [];
    S.sw = { starts: 1, last_alive: t(), resumes: 0, max_gap: 0 };
    log("dados da sessão apagados; nova sessão iniciada");
  },
  removeAll() {
    stopAll();
    S.channels = []; S.subs = [];
    log("todos os canais removidos");
  },
  exportSession() { return sessionExport(); },
};

api.runtime.onMessage.addListener((msg, _sender, reply) => {
  ready.then(async () => {
    try {
      const h = handlers[msg && msg.cmd];
      if (!h) throw new Error("comando desconhecido");
      const data = await h(msg);
      await flush();
      reply({ ok: true, data });
    } catch (e) {
      await flush();
      reply({ ok: false, error: String(e.message || e) });
    }
  });
  return true;
});

ready = init();
