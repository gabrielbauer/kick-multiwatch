const api = globalThis.browser || globalThis.chrome;
const $ = (id) => document.getElementById(id);
const HOSTS = { origins: ["https://kick.com/*", "https://*.kick.com/*"] };
const COLORS = ["#ff6f61","#5fd38a","#f2b632","#5fa8ff","#c27bff","#3fd1d9","#ff9a4d","#9be35a","#ff6fb0","#8f94ff","#4fd6b8","#e0c25a"];
const STATE = { watching: "ganhando", queued: "na fila", connecting: "conectando", error: "erro", paused: "pausado" };
let S = null, view = "Canais", confirm = "", priceDraft = null, hasPerm = true;
const fmt = (n) => n == null ? "–" : Number(n).toLocaleString("pt-BR");
const hhmm = (t) => new Date(t * 1000).toTimeString().slice(0, 5);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const live = (c) => c.livestream_id !== null && c.livestream_id !== undefined;
const earned = () => S.channels.reduce((a, c) => a + (c.earned || 0), 0);
const spent = () => S.channels.reduce((a, c) => a + (c.spent || 0), 0);

// Keeps the background alive in Firefox while this tab is open; harmless in Chrome.
try { api.runtime.connect({ name: "painel" }); } catch {}

async function cmd(name, args = {}) {
  let r;
  try { r = await api.runtime.sendMessage({ cmd: name, ...args }); }
  catch (e) { r = { ok: false, error: String(e.message || e) }; }
  if (!r || !r.ok) throw new Error((r && r.error) || "a extensão não respondeu");
  await load();
  return r.data;
}

async function load() {
  const { st } = await api.storage.local.get("st");
  if (st) { S = st; render(); }
}

function showErr(t) { $("err").textContent = t; $("err").hidden = !t; }

function render() {
  if (!S) return;
  const A = S.account || {};
  const on = hasPerm && A.state === "connected";
  $("gate").hidden = on; $("app").hidden = !on;
  if (!on) { renderGate(); return; }
  gateKey = "";
  const ch = S.channels;
  $("sUser").textContent = S.user || "conectado";
  $("sPts").textContent = ch.some((c) => c.points != null) ? fmt(ch.reduce((a, c) => a + (c.points || 0), 0)) : "–";
  $("sGain").textContent = earned() ? "+" + fmt(earned()) : "0";
  $("sSpent").textContent = spent() ? "−" + fmt(spent()) : "0";
  $("sLive").textContent = ch.filter(live).length + " / " + ch.filter((c) => c.watch === "watching").length;
  $("sState").textContent = S.paused ? "pausado" : "ativo";
  $("sState").className = S.paused ? "minus" : "plus";
  $("pause").textContent = S.paused ? "Retomar" : "Pausar";
  renderList(ch);
  if (view === "Resgates") renderResgates();
  if (view === "Opcoes") renderOpcoes();
}

function renderList(ch) {
  const list = $("list");
  if (!ch.length) { list.innerHTML = '<p class="empty">Nenhum canal ainda. Adicione um acima.</p>'; return; }
  const now = Date.now() / 1000;
  const ago = (t) => { const m = Math.floor((now - t) / 60); return m < 1 ? "agora" : "há " + m + " min"; };
  list.innerHTML = ch.map((c, i) => {
    const sub = S.subs.includes(c.slug);
    const st = !c.enabled ? "paused" : live(c) ? c.watch : "";
    const pill = live(c) ? '<span class="pill live">ao vivo</span>' : "";
    const wp = STATE[st] ? `<span class="pill ${st}">${STATE[st]}</span>` : "";
    const turn = c.in_turn && c.turn_started ? `ganhando há ${Math.floor((now - c.turn_started) / 60)} min · ` : "";
    const last = c.last_credit ? `últimos pontos ${ago(c.last_credit)} · ` : "";
    const info = live(c) ? `${turn}${last}${fmt(c.viewers)} espectadores${c.category ? " · " + esc(c.category) : ""} · ${esc(c.title)}` : `${last}offline`;
    const delta = (c.earned || c.spent)
      ? `<small>${c.earned ? `<span class="ok">+${fmt(c.earned)}</span>` : ""}${c.earned && c.spent ? " · " : ""}${c.spent ? `<span class="bad">−${fmt(c.spent)}</span>` : ""}</small>`
      : '<small class="muted">sem mudança</small>';
    const stalled = c.watch === "watching" && c.watching_since && now - c.watching_since > 720 && !c.earned
      && c.points_at > c.watching_since + 660;
    const warn = stalled ? '<div class="line2" style="color:var(--gold)">Ganhando há mais de 12 min sem pontos novos. A Kick pode não estar creditando este canal.</div>' : "";
    return `<div class="ch ${live(c) ? "" : "off"}">
      <div class="name"><span class="dot" style="background:${COLORS[c.idx % COLORS.length]}"></span><a href="https://kick.com/${esc(c.slug)}" target="_blank" rel="noopener" style="color:inherit;text-decoration:none">${esc(c.slug)}</a> ${pill} ${wp}</div>
      <div class="pts" title="Saldo atual neste canal"><b>${fmt(c.points)}</b>${delta}</div>
      <div class="info">${info}</div>
      <div class="ctl"><button class="two ${sub ? "on" : ""}" title="Sou inscrito aqui (pontos em dobro)" aria-pressed="${sub}" data-sub="${c.slug}">2×</button><button class="ic" title="Subir" aria-label="Subir ${c.slug}" data-mv="-1" data-slug="${c.slug}" ${i ? "" : "disabled"}>↑</button><button class="ic" title="Descer" aria-label="Descer ${c.slug}" data-mv="1" data-slug="${c.slug}" ${i < ch.length - 1 ? "" : "disabled"}>↓</button><button class="sw" role="switch" aria-checked="${c.enabled}" aria-label="Ganhar pontos em ${c.slug}" title="Ganhar pontos neste canal" data-sw="${c.slug}"></button><button class="ic" title="Remover" aria-label="Remover ${c.slug}" data-rm="${c.slug}">×</button></div>
      ${c.watch === "error" && c.watch_error ? `<div class="line2 bad">${esc(c.watch_error)}</div>` : ""}${warn}</div>`;
  }).join("");
}

let gateKey = "";
function renderGate() {
  const A = S.account || {}, key = hasPerm + "|" + A.state + "|" + A.error;
  if (key === gateKey) return;
  gateKey = key;
  const g = $("gate");
  const box = (inner) => `<div class="panel"><h1>Kick Multiwatch</h1>${inner}</div>`;
  if (!hasPerm) {
    g.innerHTML = box(`<p>A extensão precisa de permissão para acessar <b>kick.com</b> para ler seus pontos e ganhar tempo assistido.</p>
      <div class="row"><button class="gold" id="perm">Permitir acesso à kick.com</button></div>`);
    $("perm").onclick = async () => { await api.permissions.request(HOSTS); await checkPerm(); cmd("recheck").catch(() => {}); };
    return;
  }
  if (A.state === "loading" || A.state === "checking") {
    g.innerHTML = box('<p class="muted">Verificando seu login na Kick…</p>');
    return;
  }
  const failed = A.state === "failed";
  g.innerHTML = box(`
    <p>${failed ? "" : "<b>Faça login na Kick</b> para começar. "}A extensão usa o login que já está neste navegador: não precisa copiar nem colar nenhum token.</p>
    ${A.error ? `<p class="bad">${esc(A.error)}</p>` : ""}
    <ol><li>Abra <a href="https://kick.com" target="_blank" rel="noopener">kick.com</a> e entre na sua conta (neste mesmo navegador).</li>
    <li>Volte para esta aba. O painel abre sozinho quando o login aparecer.</li></ol>
    <div class="row"><a href="https://kick.com" target="_blank" rel="noopener"><button class="gold" type="button">Abrir kick.com</button></a><button id="recheck" class="flat">Já entrei, verificar</button></div>
    <p class="note">Seu login fica só no navegador e só é usado em pedidos para a Kick. Sair da conta em kick.com desconecta a extensão.</p>
    <p class="note">Usa endpoints internos e não documentados da Kick. Simular tempo assistido pode violar os Termos de Serviço da Kick e sua conta pode ser restringida. Use por sua conta e risco.</p>`);
  $("recheck").onclick = (e) => { e.target.disabled = true; e.target.textContent = "Verificando…"; gateKey = ""; cmd("recheck").catch(() => {}).finally(render); };
}

let resKey = "";
function renderResgates() {
  const L = S.spend_log || [], key = L.length + "|" + spent() + "|" + earned();
  if (key === resKey) return;
  resKey = key;
  const known = L.filter((e) => e.known);
  const count = {};
  known.forEach((e) => e.items.forEach((n) => (count[n] = (count[n] || 0) + 1)));
  const bal = earned() - spent();
  const rows = L.slice().reverse().map((e) => `<tr><td>${hhmm(e.at)}</td><td>${esc(e.slug)}</td>
    <td>${e.known ? e.items.map((n) => `<span class="tag">${esc(n)}</span>`).join("") : '<span class="muted">Gasto sem recompensa correspondente</span>'}</td>
    <td class="num bad">−${fmt(e.spent)}</td><td class="num muted">${fmt(e.before)} → ${fmt(e.after)}</td></tr>`).join("");
  $("vResgates").innerHTML = `<div class="cards">
      <div class="card panel"><span class="lbl">Resgates na sessão</span><b>${fmt(known.reduce((a, e) => a + e.items.length, 0))}</b></div>
      <div class="card panel"><span class="lbl">Pontos gastos</span><b class="bad">${spent() ? "−" + fmt(spent()) : "0"}</b></div>
      <div class="card panel"><span class="lbl">Pontos ganhos</span><b class="ok">${earned() ? "+" + fmt(earned()) : "0"}</b></div>
      <div class="card panel"><span class="lbl">Saldo da sessão</span><b>${bal >= 0 ? "+" : "−"}${fmt(Math.abs(bal))}</b></div>
    </div>
    ${Object.keys(count).length ? `<div class="box panel"><h2>Por recompensa</h2><div>${Object.entries(count).map(([n, k]) => `<span class="tag">${esc(n)} × ${k}</span>`).join("")}</div></div>` : ""}
    <div class="box panel"><h2>Registro de resgates</h2>
    ${L.length ? `<div class="tblwrap"><table><thead><tr><th>Hora</th><th>Canal</th><th>Recompensa</th><th class="num">Custo</th><th class="num">Saldo</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<p class="empty">Nenhum resgate nesta sessão ainda. Quando você resgatar algo na Kick, a queda no saldo aparece aqui.</p>'}
    <p class="note">Os resgates são deduzidos da queda do saldo de cada canal, comparada com os preços das recompensas em Opções. A extensão não resgata nada. Sessão iniciada em ${new Date(S.started * 1000).toLocaleString("pt-BR")}.</p></div>`;
}

let optKey = "";
function renderOpcoes() {
  const key = JSON.stringify([S.user, S.max_earning, S.rotate_every, S.next_rotation, confirm, S.prices, !!priceDraft,
    S.channels.map((c) => c.slug), S.log.slice(0, 30), S.sw]);
  if (key === optKey || (priceDraft && optKey)) return;
  optKey = key;
  const opt = (list, cur) => list.map(([v, l]) => `<option value="${v}" ${v === cur ? "selected" : ""}>${l}</option>`).join("");
  const P = priceDraft || S.prices || [];
  const conf = (id, text, yes) => confirm === id
    ? `<div class="confirm"><p style="margin:0">${text}</p><div class="row"><button class="danger" data-yes="${id}">${yes}</button><button class="flat" data-no="1">Cancelar</button></div></div>`
    : "";
  $("vOpcoes").innerHTML = `<div class="grid2">
    <div class="box panel"><h2>Conta</h2>
      <p>Conectado como <b class="ok">${esc(S.user || "?")}</b>, pelo login da Kick neste navegador.</p>
      <p class="note">Para trocar de conta, saia e entre com a outra conta em kick.com. A extensão percebe sozinha.</p>
    </div>
    <div class="box panel"><h2>Ganho de pontos</h2>
      <label class="row" for="maxe">Ganhar em <select id="maxe">${opt([[1, "1 canal"], [2, "2 canais (recomendado)"], [3, "3 canais"], [0, "todos os canais ao vivo"]], S.max_earning)}</select> por vez</label>
      <label class="row" for="rot">Trocar de canal <select id="rot" ${S.max_earning ? "" : "disabled"}>${opt([[-1, "a cada crédito (automático)"], [0, "nunca (topo da lista)"], [10, "a cada 10 min"], [15, "a cada 15 min"], [30, "a cada 30 min"], [60, "a cada hora"]], S.rotate_every)}</select></label>
      <p class="note">A Kick credita cerca de 2 canais a cada 5 minutos por conta. Canais 2× (inscrito) ganham primeiro; depois o topo da lista. ${nextRot()}</p>
    </div>
    <div class="box panel"><h2>Preços das recompensas</h2>
      <p class="note">Usados para reconhecer o que você resgatou a partir da queda do saldo. Vale para todos os canais.</p>
      <div class="prices">${P.map((p, i) => `<div class="row"><input class="nm" data-pi="${i}" data-f="name" value="${esc(p.name)}" maxlength="60" aria-label="Nome da recompensa"><input class="cost" data-pi="${i}" data-f="cost" type="number" min="1" value="${p.cost}" aria-label="Custo em pontos"><button class="flat" data-pdel="${i}" title="Remover" aria-label="Remover recompensa">×</button></div>`).join("")}</div>
      <div class="row"><button class="flat" id="padd">+ Recompensa</button><button class="gold" id="psave" ${priceDraft ? "" : "disabled"}>Salvar preços</button>${priceDraft ? '<button class="flat" id="pcancel">Descartar</button>' : ""}</div>
    </div>
    <div class="box panel"><h2>Canais</h2>
      ${S.channels.length ? `<div>${S.channels.map((c) => `<span class="tag">${esc(c.slug)} <button class="flat" style="padding:0 6px;border:0" data-rm="${c.slug}" aria-label="Remover ${esc(c.slug)}">×</button></span>`).join("")}</div>` : '<p class="note">Nenhum canal.</p>'}
      ${conf("removeAll", "Remover todos os canais da lista?", "Remover todos") || (S.channels.length ? '<div class="row"><button class="danger" data-ask="removeAll">Remover todos os canais</button></div>' : "")}
    </div>
    <div class="box panel"><h2>Dados da sessão</h2>
      <p class="note">Ganhos, gastos e o registro de resgates ficam salvos no navegador até você apagar. Os canais e preços continuam.</p>
      <div class="row"><button class="flat" id="export">Baixar sessão (.json)</button></div>
      ${conf("resetSession", "Apagar ganhos, gastos e o registro de resgates e começar uma nova sessão?", "Apagar e recomeçar") || '<div class="row"><button class="danger" data-ask="resetSession">Apagar dados da sessão</button></div>'}
    </div>
    <div class="box panel"><h2>Registro</h2>
      <p class="note">Reinícios do worker do navegador: ${S.sw.resumes} (maior pausa ${S.sw.max_gap} s).</p>
      <ul id="logbox">${S.log.slice(0, 30).map((l) => `<li>${esc(l)}</li>`).join("") || "<li>vazio</li>"}</ul>
    </div>
  </div>`;
  const draft = () => { if (!priceDraft) priceDraft = (S.prices || []).map((p) => ({ ...p })); };
  $("maxe").onchange = (e) => cmd("settings", { max_earning: +e.target.value }).catch((er) => alert(er.message));
  $("rot").onchange = (e) => cmd("settings", { rotate_every: +e.target.value }).catch((er) => alert(er.message));
  $("vOpcoes").querySelectorAll("[data-pi]").forEach((inp) => (inp.oninput = () => {
    const was = !!priceDraft; draft();
    const p = priceDraft[+inp.dataset.pi];
    p[inp.dataset.f] = inp.dataset.f === "cost" ? +inp.value : inp.value;
    if (!was) { $("psave").disabled = false; optKey = ""; }
  }));
  $("vOpcoes").querySelectorAll("[data-pdel]").forEach((b) => (b.onclick = () => { draft(); priceDraft.splice(+b.dataset.pdel, 1); optKey = ""; renderOpcoes(); }));
  $("padd").onclick = () => { draft(); priceDraft.push({ name: "Nova recompensa", cost: 100 }); optKey = ""; renderOpcoes(); };
  if ($("pcancel")) $("pcancel").onclick = () => { priceDraft = null; optKey = ""; renderOpcoes(); };
  $("psave").onclick = async () => {
    const p = priceDraft; priceDraft = null;
    try { await cmd("settings", { prices: p }); } catch (e) { priceDraft = p; alert(e.message); }
    optKey = ""; render();
  };
  $("export").onclick = async () => {
    const data = await cmd("exportSession");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    a.download = `kick-sessao-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  };
}

function nextRot() {
  if (!S.max_earning) return "";
  if (S.rotate_every === -1) return "Quando um canal recebe os pontos, a vaga vai para o canal que espera há mais tempo (ou após 7 min sem pontos).";
  if (S.next_rotation && S.rotate_every > 0) return "Próxima troca em " + Math.max(0, Math.round((S.next_rotation - Date.now() / 1000) / 60)) + " min.";
  return "";
}

function show(v) {
  view = v;
  document.querySelectorAll("nav button").forEach((b) => b.setAttribute("aria-selected", b.dataset.view === v));
  ["Canais", "Resgates", "Opcoes"].forEach((x) => ($("v" + x).hidden = x !== v));
  resKey = optKey = ""; confirm = "";
  render();
}

document.addEventListener("click", async (e) => {
  const el = e.target.closest("[data-view],[data-sub],[data-mv],[data-rm],[data-sw],[data-ask],[data-yes],[data-no]");
  if (!el) return;
  try {
    const d = el.dataset;
    if (d.view) show(d.view);
    else if (d.sub) await cmd("sub", { slug: d.sub, on: el.getAttribute("aria-pressed") !== "true" });
    else if (d.mv) await cmd("move", { slug: d.slug, delta: +d.mv });
    else if (d.rm) await cmd("remove", { slug: d.rm });
    else if (d.sw) await cmd("enable", { slug: d.sw, on: el.getAttribute("aria-checked") !== "true" });
    else if (d.ask) { confirm = d.ask; optKey = ""; renderOpcoes(); }
    else if (d.no) { confirm = ""; optKey = ""; renderOpcoes(); }
    else if (d.yes) { confirm = ""; optKey = ""; await cmd(d.yes); }
  } catch (err) {
    showErr(err.message);
  }
});

$("pause").onclick = () => cmd("pause", { on: !S.paused }).catch((e) => alert(e.message));

$("add").addEventListener("submit", async (e) => {
  e.preventDefault();
  const v = $("slug").value.trim();
  if (!v) return;
  const b = e.target.querySelector("button");
  b.disabled = true; b.textContent = "Adicionando…"; showErr("");
  for (const one of v.split(/[\s,;]+/).filter(Boolean)) {
    try { await cmd("add", { slug: one }); } catch (err) { showErr(`${one}: ${err.message}`); }
  }
  $("slug").value = "";
  b.disabled = false; b.textContent = "Adicionar";
});

// "Apoie o dev": opens the link from apoio.json in a new tab.
async function setupSupport() {
  let cfg;
  try { cfg = await (await fetch(api.runtime.getURL("apoio.json"))).json(); } catch { return; }
  if (!cfg || !cfg.ativo || !/^https:\/\//.test(cfg.link || "")) return;
  $("support").href = cfg.link;
  if (cfg.titulo) $("support").textContent = "♥ " + cfg.titulo;
  $("supportBox").hidden = false;
}

async function checkPerm() {
  hasPerm = await api.permissions.contains(HOSTS);
  gateKey = "";
  render();
}

api.storage.onChanged.addListener((c) => { if (c.st && c.st.newValue) { S = c.st.newValue; render(); } });
setInterval(() => { if (S && view === "Canais") renderList(S.channels); }, 30000);
setupSupport();
checkPerm().then(load);
